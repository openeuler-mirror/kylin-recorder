# Recorder

##Overview

Recording is a user-friendly and easy-to-use recording tool that supports microphone and system sound recording in MP3 format. It also supports functions such as file list playback, editing, deletion, and mini mode to meet your recording needs in multiple ways.

##Basic functions

The main interface is shown below.

! [] (image/main.png)

##Recording

Click the Record button to start recording and generate a waveform map in real time. During recording, click! [] (image/icon21.png) to pause/resume recording; Click! [] (image/icon20.png), which completes the recording. The default storage path is your personal music directory.

! [] (image/recording.png)

After each successful recording, the generated audio file will automatically be displayed in the file list, and can be played and deleted in the file list.

##Settings

The setting interface is shown below. Users can customize the storage path, select the recording file format, and switch sound sources.

! [] (image/14.png)

##Mini Mode

Click! [] (image/icon23.png) You can enter the mini mode and click the "Maximize" button to switch back to the original interface.

! [] (image/15.png)

##Clip

The editing interface is shown in the following figure. After entering the editing interface, you can drag the slider to edit the time node and select an appropriate time period to intercept.

! [] (image/clip.png)
