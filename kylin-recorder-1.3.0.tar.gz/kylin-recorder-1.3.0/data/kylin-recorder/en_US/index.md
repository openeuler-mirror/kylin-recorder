# Recorder

## Operation

Recorder provides a simple audio recording function, as shown in Fig 11.

![Fig 11 Recorder-big](image/11.png)

Click recording icon to enter recording interface.

Click ![](image/icon21.png) to pause/continue during recording. Click ![](image/icon20.png) to finish recording.

![Fig 12 Recording-big](image/12.png)

And the recording files will show on the right side automatically.

The settings interface as shown in Fig 12.

![Fig 13 Settings](image/13.png)
