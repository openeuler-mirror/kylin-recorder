#ifndef FILEITEM_H
#define FILEITEM_H

#include <QWidget>
#include <QString>
#include <QLabel>
#include <QSlider>
#include <QFrame>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QMenu>
#include <QAction>
#include <QFile>
#include <QDesktopServices>
#include <QTextCodec>
#include <QDebug>
#include <QStackedWidget>
#include <QProcess>
#include <QPainter>
#include <QColor>


#include "customslider.h"
#include "playcontrol.h"
#include "custombutton.h"
#include "mmediaplayer.h"
#include "mmediaplaylist.h"
#include "mylabel.h"

class FileItem : public QWidget
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.freedesktop.FileManager1")//调用DBus一定要加这一行
public:
    explicit FileItem(QString path ,QWidget *parent = nullptr);
    ~FileItem();

public:

    int m_movePos = 0;                          //每隔毫秒数所移动位置
    void setName_Time_Length(QString nameStr,QString timeStr,QString lengthStr);

private:

    QString m_filePath;                           //录音存储的文件路径
    QPalette m_pal;
    QProcess *m_processDEL = nullptr;             //删除时调用命令
    QFrame *m_splitLine = nullptr;                     //分割线
    CustomSlider *m_playSlider = nullptr;         //播放划块条
    MyLabel *m_recordFileNameLabel = nullptr;         //录音文件名
    QLabel *m_startRecordTimeLabel = nullptr;        //录音时间标签
    QLabel *m_timelengthLabel = nullptr;             //时间长度标签
    QLabel *m_seatLabel = nullptr;             //占位标签
    QString m_itemThemeColor;                     //主题颜色串

    CustomButton *m_customPauseButton = nullptr;      //暂停按钮
    CustomButton *m_customPlayButton = nullptr;       //播放按钮
    CustomButton *m_customClipButton = nullptr;       //剪裁按钮
    CustomButton *m_customDeleteButton = nullptr;     //删除按钮

    QWidget *m_itemBottomWidget = nullptr;       //列表项的底部Wid，有label和button两组控件
    QWidget *m_fileNameDateTimeWidget = nullptr;//文件名和日期时间的Wid

    QHBoxLayout *m_itemBottomLayout = nullptr;        //列表项的底部布局有label和button两组控件
    QVBoxLayout *m_fileNameDateTimeLayout = nullptr; //文件名和录制时间布局
    QVBoxLayout *m_timeLengthLayout = nullptr;        //列表项时间长度布局
    QVBoxLayout *m_itemLayout = nullptr;            //item总布局

    QStackedWidget *m_splitLinestackWidget = nullptr;  //分割线堆叠wid
    QStackedWidget *m_buttonStackWidget = nullptr;        //有按钮的堆叠Wid
    QStackedWidget *m_itemStackWidget = nullptr;       //整个item界面的堆叠布局(包括播放、剪裁两个界面)

    QWidget *m_itemWidget = nullptr;                   //itemWid
    QWidget *m_firstWidget = nullptr;
    QWidget *m_threeButtonWidget = nullptr;            //三个按钮的Wid
    QHBoxLayout *m_threeButtonLayout = nullptr;     //列表项的3个按钮布局

    QMenu *m_menu = nullptr;
    QAction *m_actionSave= nullptr;//另存为
    QAction *m_actionOpenFolder = nullptr;//打开此音频所在文件夹

    void initItemWid();                 //初始化ItemWid
    void setItemWid();                  //设置ItemWid的界面
    void initThemeGsetting();           //配置文件初始化主题
    void themeStyle(QString themeColor);
    void isOtherClipWidOpen();          //是否存在其他剪辑界面，若存在则此方法会将其他收回
    int getInternalMoveTime();          //获取间隔时间


    void _processStart(QString cmd , QStringList arguments = QStringList());
    void deleteFile(QString savepath);
    void processLog();//命令日志

    void enterEvent(QEvent *) override;
    void leaveEvent(QEvent *) override;
    void mousePressEvent(QMouseEvent *) override;
    bool eventFilter(QObject *obj, QEvent *event);//事件过滤器

public slots:

    void handlePlay();      //控制播放
    void handlePause();     //控制暂停
    void delAudioFile();    //删除文件
    void setSliderPos(qint64 pos);  //设置进度条位置
    void handleMove();      //控制滑块移动
    void itemFontStyle(QFont fontStyle);    //item字体样式
    void stateChanged(QMediaPlayer::State); //状态的变化

private slots:

    void rightClickedMenuRequest(); //右击弹出Menu菜单选择另存为和打开文件位置
    void actionSaveasSlot();        //另存为
    void actionOpenFolderSlot();    //打开文件所在位置

    void toClipPage();              //切换至剪裁窗口
    void cancel();                  //取消剪辑
    void finish();                  //剪辑完成
    void updateListDisplay(QString filePath);

signals:

    void addListItemSignal(QString addfilePath,QString addTime);



};

#endif // FILEITEM_H
