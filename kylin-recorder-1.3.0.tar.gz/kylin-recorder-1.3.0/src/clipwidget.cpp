#include "clipwidget.h"

#include "tools.h"
#include "mainwindow.h"

#define MIN(x,y) (x)<(y)?(x):(y)
#define MAX(x,y) (x)>(y)?(x):(y)
ClipWidget::ClipWidget(QString clipAudioPath,QWidget *parent) : QWidget(parent)
{

    clipPath = clipAudioPath;//传入的某音频的路径
    qDebug()<<"获取剪裁的音频路径"<<clipPath;
    initClipWid();
    setClipWid();
}

int ClipWidget::getInterval_Time(QString filePath)
{
     QFile file(filePath);
     int time = file.size()/96000;
     int x = 1;
     if(time >= 1){
         x = time*1000/railWid->width();
     }else{
         x = (time+1)*1000/railWid->width();
     }
     qDebug()<<"间隔"<<x<<"ms运动一次"<<"railWid宽度:"<<railWid->width();
     return x;
}

void ClipWidget::initClipWid()
{
    m_Wavefile = new AudioFileProcess(this);
    process = new QProcess(this);
    dur_timelb = new QLabel(this);//总时长标签
    clip_playBtn = new CustomButton(":/png/png/start_mini.png",
                                    ":/png/png/start_mini_hover.png",
                                    ":/png/png/start_mini_click.png",this);
    clip_pauseBtn = new CustomButton(":/png/png/pause_mini.png",
                                     ":/png/png/pause_mini_hover.png",
                                     ":/png/png/pause_mini_click.png");
    cancelButton = new QPushButton(this);//取消
    finishButton = new QPushButton(this);//完成
    railWid = new QWidget(this);//轨道的Wid
    scopeFrame = new ScopeFrame(this);
//    //设置具体阴影
//    QGraphicsDropShadowEffect *shadow_effect = new QGraphicsDropShadowEffect(this);
//    shadow_effect->setOffset(0, 0);
//    //阴影颜色
//    shadow_effect->setColor(QColor(55,144,250,127));
//    //阴影半径
//    shadow_effect->setBlurRadius(22);
//    railWid->setGraphicsEffect(shadow_effect);
//    railWid->setFrameStyle(QFrame::Box);
//    railWid->setLineWidth(1);
    bottomWid = new QWidget(this);//底部Wid

    leftBtn = new ClipButton(":/svg/svg/blue_left_prev.svg",this);

    rightBtn = new ClipButton(":/svg/svg/blue_right_prev.svg",this);
    cursor = new QFrame(this);//设置游标在父类railWid上

    waveLayout = new QHBoxLayout();
    bottomLayout = new QHBoxLayout();
    clipLayout = new QVBoxLayout();

    connect(cancelButton,&QPushButton::clicked,this,&ClipWidget::cancel_ClipSlot);
    connect(finishButton,&QPushButton::clicked,this,&ClipWidget::finish_ClipSlot);

    connect(leftBtn,&ClipButton::leftBtn_ReleaseStartPlayer_Signal,this,&ClipWidget::leftBtn_ReleaseStartPlayer_Slot);
    connect(this,&ClipWidget::computeLeftBtnL_To_RightBtnRWidth,scopeFrame,&ScopeFrame::computeClipAreaWidth);
    connect(rightBtn,&ClipButton::rightBtn_ReleaseGetEndPositon_Signal,this,&ClipWidget::rightBtn_ReleaseGetEndPositon_Slot);
    connect(leftBtn,&ClipButton::btn_MoveSignal,this,&ClipWidget::leftBtn_Move_Slot);
    connect(rightBtn,&ClipButton::btn_MoveSignal,this,&ClipWidget::rightBtn_Move_Slot);
    connect(clip_playBtn,&CustomButton::clicked,this,&ClipWidget::play_ClipFile);
    connect(clip_pauseBtn,&CustomButton::clicked,this,&ClipWidget::pause_ClipFile);
    connect(this,&ClipWidget::wave_AnalysisStart,MainWindow::mutual,&MainWindow::handlingSlot);
    connect(this,&ClipWidget::wave_AnalysisFinish,this,&ClipWidget::wave_Analysis_Tips);
    connect(PlayControl::getInstance().clipMoveTimer,&QTimer::timeout,this,&ClipWidget::cursorMove);
    connect(PlayControl::getInstance().getPlayer(),SIGNAL(positionChanged(qint64)),this,SLOT(positionChange(qint64)));


    connect(process, SIGNAL(finished(int)), this, SLOT(processFinish(int)), Qt::UniqueConnection);
    connect(m_Wavefile,&AudioFileProcess::toPaintWave,this,&ClipWidget::toPaintWave);

}

void ClipWidget::setClipWid()
{
    for (int i=0;i<CLIP_RECTANGLE_COUNT;i++)//频率直方图
    {
        myWave *wave = new myWave(true,this);//初始化小矩形
        wave->setRange(0,100);
        mywave.append(wave);
        waveLayout->addWidget(wave,0,Qt::AlignCenter);
    }

    cancelButton->setFixedHeight(30);
    finishButton->setFixedHeight(30);
    qDebug()<<"初始化矩形框"<<mywave.count();
    waveLayout->setSpacing(0);
    waveLayout->setContentsMargins(0,0,0,0);

    railWid->setLayout(waveLayout);
    railWid->setFixedHeight(24);

    bottomLayout->addWidget(dur_timelb);
    bottomLayout->addWidget(clip_playBtn,0,Qt::AlignCenter);
    bottomLayout->removeWidget(clip_pauseBtn);
    bottomLayout->addWidget(cancelButton);
    bottomLayout->addWidget(finishButton);
    bottomLayout->setSpacing(0);
    bottomLayout->setContentsMargins(0,0,0,0);
    bottomWid->setLayout(bottomLayout);

    clipLayout->addWidget(railWid);
    clipLayout->addWidget(bottomWid);
    clipLayout->setSpacing(0);
    clipLayout->setContentsMargins(0,0,0,0);
    this->setLayout(clipLayout);

    leftBtn->setObjectName("leftBtn");
    rightBtn->setObjectName("rightBtn");
    cursor->setFrameShape(QFrame::VLine);
    cursor->setFixedSize(1,24);

    cursor->setParent(scopeFrame);
    scopeFrame->setParent(railWid);

    leftBtn->setFixedSize(16,24);
    leftBtn->setParent(scopeFrame);//设置左按钮在父类railWid上
    rightBtn->setFixedSize(16,24);
    rightBtn->setParent(scopeFrame);//设置右按钮在父类railWid上

    qDebug()<<"轨道的宽度:"<<railWid->width()<<railWid->height()<<leftBtn->width();

    dur_timelb->setText(MainWindow::mutual->playerTotalTime(clipPath));
    clip_playBtn->setFixedSize(16,16);
    clip_playBtn->setToolTip(tr("Audition"));
    clip_pauseBtn->setFixedSize(16,16);
    clip_pauseBtn->setToolTip(tr("Pause"));

    cancelButton->setFixedWidth(70);
    cancelButton->setText(tr("Cancel"));
    cancelButton->setFlat(true);
    finishButton->setFixedWidth(70);
    finishButton->setText(tr("Finish"));
    finishButton->setFlat(true);

}

void ClipWidget::resizeEvent(QResizeEvent *event)
{
    Q_UNUSED(event);

    QRect rect=railWid->geometry();
    qDebug()<<"触发了!"<<rect<<"railWid的宽度:"<<rect.width();
    scopeFrame->setFixedSize(rect.width(),rect.height());
    scopeWidth = rect.width();
    rightBtn->move(scopeFrame->width()-rightBtn->width(),0);
    leftBtn->move(0,0);
    cursor->move(leftBtn->pos().rx(),0);
    emit computeLeftBtnL_To_RightBtnRWidth(leftBtn->pos().rx(),rightBtn->pos().rx()+rightBtn->width(),railWid->width(),mywave);//用于框出初始剪裁范围

}

void ClipWidget::display_Wave()
{

    if(clipPath == "")
        return;
    emit wave_AnalysisStart();
    m_Wavefile->wavFile_Analy(clipPath);
}

void ClipWidget::wave_Analysis_Tips(bool isOk)
{
    qDebug() << "完成"<<isOk;
    MainWindow::mutual->m_tipWindow->hide();
}

void ClipWidget::toPaintWave(int index,int value)
{
    if(value>32000)
        value = 32000;
    if(index < CLIP_RECTANGLE_COUNT - 1){
        mywave.at(index)->setValue(value/300);
    }else{
        emit wave_AnalysisFinish(true);
    }

}

void ClipWidget::leftBtn_ReleaseStartPlayer_Slot(int leftButton_absolutePos)
{
    int padding = 0;
    FFUtil fu;
    fu.open(clipPath);
    int64_t audio_duration = fu.getDuration(clipPath);//获取的是ms
    if(leftButton_absolutePos>0&&leftButton_absolutePos<railWid->width())
    {
        padding = rightBtn->pos().rx() - leftBtn->pos().rx();
        if(padding >0)
        {

            //除去两个滑块所占位置剩余的部分即为轨道,轨道宽度为wave除去两个滑块的宽度
            currentStartPos = static_cast<int64_t>(audio_duration)*leftButton_absolutePos/railWid->width();
            currentEndPos = static_cast<int64_t>(audio_duration)*(rightBtn->pos().rx()+rightBtn->width())/railWid->width();
            qDebug()<<"左滑块左边界相对轨道的位置"<<leftBtn->pos().rx()
                    <<"轨道长度:"<<railWid->width()
                    <<"歌曲路径:"<<clipPath
                    <<"当前播放歌曲的总长度"<<audio_duration
                    <<"当前播放位置:"<<currentStartPos;
            QTime currentTime(static_cast<int64_t>(currentStartPos) /1000/3600,
                              static_cast<int64_t>(currentStartPos) / 60000,
                              static_cast<int64_t>((currentStartPos % 60000) / 1000.0));
            QString current_timeStr = currentTime.toString("hh:mm:ss");
            timeEditStartTime = QTime(0,0,0,0).addMSecs(int(currentStartPos)).toString(QString::fromLatin1("hh:mm:ss.zzz"));
            timeEditEndTime = QTime(0,0,0,0).addMSecs(int(currentEndPos)).toString(QString::fromLatin1("hh:mm:ss.zzz"));
            qDebug()<<"timeEditStartTime:剪辑开始毫秒级"<<timeEditStartTime<<"剪裁结束时间:"<<timeEditEndTime;
            dur_timelb->setText(current_timeStr);//获取裁剪开始时间
            bottomLayout->insertWidget(1,clip_pauseBtn,0,Qt::AlignCenter);
            bottomLayout->removeWidget(clip_playBtn);
            clip_playBtn->setParent(NULL);
            PlayControl::getInstance().play_Audio(clipPath);//后面放进点试听按钮时再开始播放，防止没开始播放音频会导致获取当前播放歌曲的总长度为0
            if(PlayControl::getInstance().getAudioState() == QMediaPlayer::PlayingState){
                qDebug()<<"相对位置+按钮宽度=游标的位置";
                clipMovePos = leftBtn->pos().rx();//相对位置+按钮宽度=游标的位置
                cursor->move(clipMovePos,0);
                emit computeLeftBtnL_To_RightBtnRWidth(leftBtn->pos().rx(),rightBtn->pos().rx()+rightBtn->width(),railWid->width(),mywave);
            }else{
                qDebug()<<"没播放过从0开始";
                clipMovePos = 0;
            }
            PlayControl::getInstance().setPosition(currentStartPos);
            PlayControl::getInstance().clipMoveTimer->start(getInterval_Time(clipPath));//左按钮移动后,游标也从左按钮移动的位置处开始
            qDebug()<<"左按钮左边界相对位置:"<<leftButton_absolutePos;


        }
    }
    if(leftButton_absolutePos > rightBtn->pos().rx())
    {
        QTime currentTime(static_cast<int64_t>(currentStartPos)/1000/3600,
                          static_cast<int64_t>(currentStartPos) / 60000,
                          static_cast<int64_t>((currentStartPos % 60000) / 1000.0));
        QString start_timeStr = currentTime.toString("hh:mm:ss");
        dur_timelb->setText(start_timeStr);//获取裁剪开始时间=右按钮左边界的相对位置-5
    }
    if(leftButton_absolutePos <= 0)
    {
        dur_timelb->setText("00:00:00");//获取裁剪开始时间
        timeEditStartTime = QTime(0,0,0,0).addMSecs(int(currentStartPos)).toString(QString::fromLatin1("hh:mm:ss.zzz"));
    }
}

void ClipWidget::positionChange(qint64 pos)
{
    if(PlayControl::getInstance().getAudioState() == QMediaPlayer::PlayingState)
    {

        QTime currentTime(static_cast<int64_t>(pos) / (60*60*1000) ,
                          static_cast<int64_t>(pos) % (60*60*1000) / 60000,
                          static_cast<int64_t>((pos % (60*1000)) / 1000.0));
        QString current_timeStr = currentTime.toString("hh:mm:ss");
        dur_timelb->setText(current_timeStr);

    }
}

//右按钮释放获取剪裁结束位置
void ClipWidget::rightBtn_ReleaseGetEndPositon_Slot(int rightButton_absolutePos)
{
    int padding = 0;
    FFUtil fu;
    fu.open(clipPath);
    int64_t audio_duration = fu.getDuration(clipPath);
    if(rightButton_absolutePos>0&&rightButton_absolutePos<railWid->width())
    {
        padding = rightBtn->pos().rx() - leftBtn->pos().rx();
        if(padding >= 0)
        {
            currentStartPos = static_cast<int64_t>(audio_duration)*leftBtn->pos().rx()/railWid->width();
            currentEndPos = static_cast<int64_t>(audio_duration)*rightButton_absolutePos/railWid->width();
            QTime currentTime(static_cast<int64_t>(currentEndPos) /1000/3600,
                              static_cast<int64_t>(currentEndPos) / 60000,
                              static_cast<int64_t>((currentEndPos % 60000) / 1000.0));
            QString end_timeStr = currentTime.toString("hh:mm:ss");
            timeEditStartTime = QTime(0,0,0,0).addMSecs(int(currentStartPos)).toString(QString::fromLatin1("hh:mm:ss.zzz"));
            timeEditEndTime = QTime(0,0,0,0).addMSecs(int(currentEndPos)).toString(QString::fromLatin1("hh:mm:ss.zzz"));
            qDebug()<<"timeEditEndTime:剪辑结束毫秒级"<<timeEditEndTime;
            dur_timelb->setText(end_timeStr);//获取裁剪结束时间
            emit computeLeftBtnL_To_RightBtnRWidth(leftBtn->pos().rx(),rightBtn->pos().rx()+rightBtn->width(),railWid->width(),mywave);

        }
        else
        {
            qDebug()<<"内边距为负值!";
        }
    }
    //如果绝对位置>轨道长度,则剪裁结束时间为文件总时长
    if(rightButton_absolutePos >= railWid->width())
    {
        QTime totalTime(static_cast<int64_t>(audio_duration)/1000/3600,
                       (static_cast<int64_t>(audio_duration)/60000) % 60,
                       (static_cast<int64_t>(audio_duration) / 1000) % 60);
        dur_timelb->setText(totalTime.toString("hh:mm:ss"));//获取裁剪结束时间
        timeEditEndTime = QTime(0,0,0,0).addMSecs(int(currentEndPos)).toString(QString::fromLatin1("hh:mm:ss.zzz"));

    }
    //如果绝对位置<0,则剪裁结束时间为
    if(rightButton_absolutePos < 0||padding < 0)
    {
        int currentPos = static_cast<int>(PlayControl::getInstance().getPlayer()->duration())/railWid->width()*(leftBtn->pos().rx()+5);
        QTime currentTime(0,static_cast<int>(currentPos) / 60000, static_cast<int>((currentPos % 60000) / 1000.0));
        QString end_timeStr = currentTime.toString("hh:mm:ss");
        dur_timelb->setText(end_timeStr);//获取裁剪结束时间=左按钮右边界的相对位置+5
        qDebug()<<"左按钮右边界的相对位置+5:"<<leftBtn->pos().rx()+5;
    }

}

void ClipWidget::cancel_ClipSlot()
{
    //点击取消剪裁按钮
    emit cancel_ClipSignal();
}

void ClipWidget::finish_ClipSlot()
{
    //点击剪裁完成的按钮
    qDebug()<<"按压了右键!弹出Menu菜单";
    menu = new QMenu();
    actionSave = new QAction();
    actionCover = new QAction();

    connect(actionSave,&QAction::triggered,this,&ClipWidget::save_NewRecord);
    connect(actionCover,&QAction::triggered,this,&ClipWidget::cover_CurRecord);

    actionSave->setText(tr("Save New"));
    actionCover->setText(tr("Cover Current"));

    menu->addAction(actionSave);
    menu->addAction(actionCover);//2020/12/12禁用
    menu->exec(QCursor::pos());

    menu->deleteLater();
    actionSave->deleteLater();
    actionCover->deleteLater();
}

void ClipWidget::save_NewRecord()
{
    //选择文件目录
    QString selectDirPath = "";
    selectDirPath = QFileDialog::getExistingDirectory(
                            MainWindow::mutual,
                            tr("Select a file storage directory"),
                            "/");
    qDebug()<<"保存为新录音"<<selectDirPath;
    FFUtil fu;
    fu.open(clipPath);
    int64_t audio_duration = fu.getDuration(clipPath);
    oldFileName = clipPath;
    newFileName = QFileInfo(clipPath).path()+"/"+QFileInfo(clipPath).baseName()+".wav";
    int value = Tools::inputEditJudge(selectDirPath + "/");
    int End_Start_Time = int(currentEndPos - currentStartPos);
    qDebug()<<"End_Start_Time :"<<End_Start_Time;
    if(End_Start_Time >= 1000){

        if(value == 1){

            QFile::rename(clipPath,newFileName);
            fileClipPath = selectDirPath + "/"+"Clip" +
                    QDateTime::currentDateTime().toString("yyyyMMddhhmmss") +
                    "." + QFileInfo(newFileName).completeSuffix();
            QString cmd = "ffmpeg -i \"" + newFileName + "\" -y -ss " +
                    timeEditStartTime + " -to " +
                    timeEditEndTime + " -acodec copy \"" +
                    fileClipPath + "\"";
            process->start(cmd);

        }else{

            return ;
        }

    }else{
        QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                             tr("The duration of the clip cannot be less than 1s, "
                                "and you must drag at least one slider to start this activity!"));
        return ;
    }

}

void ClipWidget::cover_CurRecord()
{
    qDebug()<<"覆盖当前录音"<<QFileInfo(clipPath).absoluteDir().absolutePath();
    FFUtil fu;
    fu.open(clipPath);
    int64_t audio_duration = fu.getDuration(clipPath);
    oldFileName = clipPath;
    newFileName = QFileInfo(clipPath).path()+"/"+QFileInfo(clipPath).baseName()+".wav";
    QString curDir = QFileInfo(clipPath).absoluteDir().absolutePath();
    int End_Start_Time = int(currentEndPos - currentStartPos);
    if(End_Start_Time >= 1000){

        QMessageBox msg3(QMessageBox::Question,tr("Hint"),
                         tr("This will overwrite the original file path,are you sure?"), QMessageBox::NoButton);
        msg3.setParent( MainWindow::mutual );
        QPushButton *btnYes = msg3.addButton(tr("OK"), QMessageBox::YesRole);
        QPushButton *btnNo  = msg3.addButton(tr("Cancel"), QMessageBox::NoRole);
        msg3.exec();
        if ((QPushButton*)msg3.clickedButton() == btnYes) {

            qDebug()<<"确定 ";
            isCover = true;
            QFile::rename(clipPath,newFileName);
            fileClipPath = curDir + "/"+"Clip" +
                    QDateTime::currentDateTime().toString("yyyyMMddhhmmss") +
                    "." + QFileInfo(newFileName).completeSuffix();
            QString cmd = "ffmpeg -i \"" + newFileName + "\" -y -ss " +
                    timeEditStartTime + " -to " +
                    timeEditEndTime + " -acodec copy \"" +
                    fileClipPath + "\"";
            process->start(cmd);

        } else if ((QPushButton*)msg3.clickedButton() == btnNo) {

            qDebug()<<"取消 ";
            isCover = false;
            return ;
        }

    }else{
        QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                             tr("The duration of the clip cannot be less than 1s, "
                                "and you must drag at least one slider to start this activity!"));
        return ;
    }
}

void ClipWidget::processFinish(int x)
{
    qDebug()<<"x = "<<x;//x = 0 成功
    QString endClipPath = QFileInfo(fileClipPath).path()+"/"+QFileInfo(fileClipPath).baseName()+".mp3";
    QFile::rename(newFileName,QFileInfo(newFileName).path()+"/"+QFileInfo(newFileName).baseName()+".mp3");
    QFile::rename(fileClipPath,endClipPath);
    if(!x){
        QMessageBox::information(MainWindow::mutual, tr("Clip Finished!"),
                                 tr("New File:")+endClipPath);
        qDebug()<<"剪裁完成了"<<clipPath<<"开始:"<<currentStartPos<<"截止"<<currentEndPos;
        if(isCover){//是否是覆盖原路径,默认不覆盖原路径
            qDebug()<<"原路径:"<<clipPath;
            QFile::remove(clipPath);
        }
        emit finish_ClipSignal();
        emit coverUpdateListSignal(endClipPath);
    }
    isCover = false;

}

//点试听按钮时再开始播放，防止没开始播放音频会导致获取当前播放歌曲的总长度为0
void ClipWidget::play_ClipFile()
{
    bottomLayout->insertWidget(1,clip_pauseBtn,0,Qt::AlignCenter);
    bottomLayout->removeWidget(clip_playBtn);
    clip_playBtn->setParent(NULL);
    clipMovePos = leftBtn->pos().rx();
    PlayControl::getInstance().setPosition(currentStartPos);
    PlayControl::getInstance().play_Audio(clipPath);//点试听按钮时再开始播放，防止没开始播放音频会导致获取当前播放歌曲的总长度为0
    PlayControl::getInstance().clipMoveTimer->start(getInterval_Time(clipPath));//播放时,游标也从左按钮移动的位置处开始
}

void ClipWidget::pause_ClipFile()
{
    bottomLayout->insertWidget(1,clip_playBtn,0,Qt::AlignCenter);
    bottomLayout->removeWidget(clip_pauseBtn);
    clip_pauseBtn->setParent(NULL);
    PlayControl::getInstance().getPlayer()->stop();
    PlayControl::getInstance().clipMoveTimer->stop();
}

void ClipWidget::leftBtn_Move_Slot(int leftPos_x)
{
//    qDebug()<<"左按钮移动:";
    Arightx = leftPos_x+leftBtn->width();
    Bleftx = rightBtn->pos().rx();
//    qDebug()<<"左箭头的位置:"<<leftPos_x<<"左箭头的右侧:"<<Arightx<<";"<<"右箭头的左侧:"<<Bleftx;

    if(Arightx >= Bleftx - 5)
    {
        leftPos_x = Bleftx-5-leftBtn->width();
    }
    if(leftBtn->pos().rx() == leftPos_x)
    {
        return;
    }
    leftBtn->move(leftPos_x,leftBtn->pos().ry());
}

void ClipWidget::rightBtn_Move_Slot(int RightPos_x)
{
//    qDebug()<<"右按钮移动:"<<RightPos_x;
    Arightx = leftBtn->pos().rx() + leftBtn->width();
//    qDebug()<<"右箭头的左侧:"<<RightPos_x<<";"<<"左箭头的右侧:"<<Arightx;

    if(RightPos_x<=Arightx+5)
    {
        RightPos_x = Arightx + 5;
    }
    if(rightBtn->pos().rx() == RightPos_x){

        return;

    }else if(RightPos_x>railWid->width()){

        rightBtn->move(railWid->width()-rightBtn->width()-1,rightBtn->pos().ry());
        return;
    }
    rightBtn->move(RightPos_x,rightBtn->pos().ry());

}

void ClipWidget::cursorMove()
{
    cursor->raise();//持续让游标置顶
    if(clipMovePos<(rightBtn->pos().rx()+rightBtn->width()))//游标位置到右滑块的右边界后停止
    {
        cursor->move(clipMovePos,0);
        clipMovePos++;
    }
    else
    {
        qDebug()<<"停止了"<<clipMovePos<<"右滑块右边界"<<rightBtn->pos().rx()+rightBtn->width();
        PlayControl::getInstance().getPlayer()->stop();
        PlayControl::getInstance().clipMoveTimer->stop();
        bottomLayout->insertWidget(1,clip_playBtn,0,Qt::AlignCenter);
        bottomLayout->removeWidget(clip_pauseBtn);
        clip_pauseBtn->setParent(NULL);
        clipMovePos = 0;
    }
}


ClipWidget::~ClipWidget()
{
    qDebug()<<"释放:ClipWidget";
    this->deleteLater();
}


