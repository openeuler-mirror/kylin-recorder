#include "playcontrol.h"

PlayControl::PlayControl(QObject *parent) : QObject(parent)
{
    player = new QMediaPlayer(this);
    moveTimer = new QTimer(this);       //QTimer
    clipMoveTimer = new QTimer(this);
    qDebug()<<"执行1次";
}

QMediaPlayer::State PlayControl::getAudioState()
{
    m_state = player->state();
    return m_state;
}

void PlayControl::play_Audio(QString filePath)
{

    if(isPlayingPath != filePath){

        isPlayingPath = filePath;//非原路径的播放
        player->setMedia(QUrl::fromLocalFile(filePath));
        player->setVolume(85);
        player->play();
        qDebug()<<"非原路径播放:"<<filePath;

    }else{
        player->play();
        qDebug()<<"原路径播放:"<<filePath;
    }
}

void PlayControl::pause_Audio(QString filePath)
{
    qDebug()<<"暂停了:"<<filePath;
    player->pause();

}

void PlayControl::setPosition(qint64 position)
{
    if (qAbs(player->position() - position) > 99)
        player->setPosition(position);
    qDebug()<<"数值:"<<position;
}

PlayControl::~PlayControl()
{
}
