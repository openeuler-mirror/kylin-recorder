#include "menumodule.h"
#include "mainwindow.h"
#include "xatom-helper.h"
menuModule::menuModule(QWidget *parent = nullptr) : QWidget(parent)
{
    init();
}

void menuModule::init(){
    initAction();
    setStyle();
}

void menuModule::initAction(){
    m_iconSize = QSize(30,30);
    m_menuButton = new QToolButton(MainWindow::mutual->m_titleRightWidget);
    m_aboutWindow = new QWidget();
    m_mainLayout = new QVBoxLayout();
    m_font = QFont();
    m_font.setPixelSize(14);
    m_titleLayout = initTitleBar();
    m_bodyLayout = initBody();
    m_menu = new QMenu();
    QList<QAction *> actions ;
    QAction *actionSetting = new QAction(m_menu);
    actionSetting->setText(tr("Settings"));
//    actionSetting->setFont(ft);
    QAction *actionTheme = new QAction(m_menu);
    actionTheme->setText(tr("Theme"));
    actionTheme->setFont(m_font);
    QAction *actionHelp = new QAction(m_menu);
    actionHelp->setText(tr("Help"));
//    actionHelp->setFont(ft);
    QAction *actionAbout = new QAction(m_menu);
    actionAbout->setText(tr("About"));
//    actionAbout->setFont(ft);
    QAction *actionQuit = new QAction(m_menu);
    actionQuit->setText(tr("Quit"));
//    actionQuit->setFont(ft);
    actions<<actionSetting/*<<actionTheme*/<<actionHelp<<actionAbout<<actionQuit;//暂时禁掉主题切换按钮
    m_menu->addActions(actions);
//    互斥按钮组
    QMenu *themeMenu = new QMenu;
    QActionGroup *themeMenuGroup = new QActionGroup(this);
    QAction *autoTheme = new QAction("Auto",this);
    themeMenuGroup->addAction(autoTheme);
    themeMenu->addAction(autoTheme);
    autoTheme->setCheckable(true);
    QAction *lightTheme = new QAction("Light",this);
    themeMenuGroup->addAction(lightTheme);
    themeMenu->addAction(lightTheme);
    lightTheme->setCheckable(true);
    QAction *darkTheme = new QAction("Dark",this);
    themeMenuGroup->addAction(darkTheme);
    themeMenu->addAction(darkTheme);
    darkTheme->setCheckable(true);
    QList<QAction* > themeActions;
    themeActions<<autoTheme<<lightTheme<<darkTheme;
//    autoTheme->setChecked(true);
    actionTheme->setMenu(themeMenu);
    m_menuButton->setMenu(m_menu);
    connect(m_menu,&QMenu::triggered,this,&menuModule::triggerMenu);
    initGsetting();
    setThemeFromLocalThemeSetting(themeActions);
    themeUpdate();
    connect(themeMenu,&QMenu::triggered,this,&menuModule::triggerThemeMenu);
    connect(this,&menuModule::setSignal,MainWindow::mutual,&MainWindow::goset);
    connect(this,&menuModule::menuModuleClose,MainWindow::mutual,&MainWindow::close);
    connect(this,&menuModule::menuModuleSetThemeStyle,MainWindow::mutual,[=](QString str){
        MainWindow::mutual->m_limitThemeColor = str;
        qDebug()<<"限制主题颜色为"<<MainWindow::mutual->m_limitThemeColor<<str;
    });
}

void menuModule::setThemeFromLocalThemeSetting(QList<QAction* > themeActions)
{
#if DEBUG_MENUMODULE
    confPath = "org.kylin-recorder-data.settings";
#endif
    m_pGsettingThemeStatus = new QGSettings(m_configPath.toLocal8Bit());
    QString appConf = m_pGsettingThemeStatus->get("thememode").toString();
    if("lightonly" == appConf){
        themeStatus = themeLightOnly;
        themeActions[1]->setChecked(true);   //程序gsetting中为浅色only的时候就给浅色按钮设置checked
    }else if("darkonly" == appConf){
        themeStatus = themeBlackOnly;
        themeActions[2]->setChecked(true);
    }else{
        themeStatus = themeAuto;
        themeActions[0]->setChecked(true);
    }
}

void menuModule::themeUpdate(){
    if(themeStatus == themeLightOnly)
    {
        setThemeLight();
    }else if(themeStatus == themeBlackOnly){
        setThemeDark();
    }else{
        setStyleByThemeGsetting();
    }
}

void menuModule::setStyleByThemeGsetting(){
    QString nowThemeStyle = m_pGsettingThemeData->get("styleName").toString();
    if("ukui-dark" == nowThemeStyle || "ukui-black" == nowThemeStyle)
    {
        setThemeDark();
    }else{
        setThemeLight();
    }
}

void menuModule::triggerMenu(QAction *act){


    QString str = act->text();
    if(tr("Quit") == str){
        emit menuModuleClose();               //退出
    }else if(tr("About") == str){
        aboutAction();                        //关于
    }else if(tr("Help") == str){
        helpAction();                         //帮助
    }else if(tr("Settings") == str){
        emit setSignal();                     //设置
    }
}

void menuModule::triggerThemeMenu(QAction *act){
    if(!m_pGsettingThemeStatus)
    {
        m_pGsettingThemeStatus = new QGSettings(m_configPath.toLocal8Bit());  //m_pGsettingThemeStatus指针重复使用避免占用栈空间
    }
    QString str = act->text();
    if("Light" == str){
        themeStatus = themeLightOnly;
        disconnect(m_pGsettingThemeData,&QGSettings::changed,this,&menuModule::dealSystemGsettingChange);
        m_pGsettingThemeStatus->set("thememode","lightonly");
        qDebug()<<m_pGsettingThemeStatus->get("thememode").toString();
        setThemeLight();
    }else if("Dark" == str){
        themeStatus = themeBlackOnly;
        disconnect(m_pGsettingThemeData,&QGSettings::changed,this,&menuModule::dealSystemGsettingChange);
        m_pGsettingThemeStatus->set("thememode","darkonly");
        qDebug()<<m_pGsettingThemeStatus->get("thememode").toString();
        setThemeDark();
    }else{
        themeStatus = themeAuto;
        m_pGsettingThemeStatus->set("thememode","auto");
        initGsetting();
//        updateTheme();
        themeUpdate();
    }
}

void menuModule::aboutAction(){
//    关于点击事件处理
    initAbout();
}

void menuModule::helpAction(){
//    帮助点击事件处理
#if DEBUG_MENUMODULE
    appName = "kylin-recorder";
#endif
    if(!m_ipcDbus){
        m_ipcDbus = new DaemonDbus();
    }

    if(!m_ipcDbus->daemonIsNotRunning()){
        m_ipcDbus->showGuide(m_appName);
    }
}

void menuModule::initAbout(){
    m_aboutWindow->setWindowFlag(Qt::Tool);//此代码必须在此窗管协议前，否则此模态窗口背景不变灰
    MotifWmHints hints;
    hints.flags = MWM_HINTS_FUNCTIONS|MWM_HINTS_DECORATIONS;
    hints.functions = MWM_FUNC_ALL;
    hints.decorations = MWM_DECOR_BORDER;
    XAtomHelper::getInstance()->setWindowMotifHint(m_aboutWindow->winId(), hints);

    m_aboutWindow->setAttribute(Qt::WA_ShowModal, true);//模态窗口
    m_aboutWindow->setFixedSize(420,400);
    m_aboutWindow->setMinimumHeight(324);
    m_mainLayout->setMargin(0);
    m_mainLayout->addLayout(m_titleLayout);
    m_mainLayout->addLayout(m_bodyLayout);
    m_mainLayout->addStretch();
    m_aboutWindow->setLayout(m_mainLayout);
    m_aboutWindow->setWindowTitle(tr("About"));

    //TODO:在屏幕中央显示
//    QRect availableGeometry = qApp->primaryScreen()->availableGeometry();
//    aboutWindow->move((availableGeometry.width()-aboutWindow->width())/2,(availableGeometry.height()- aboutWindow->height())/2);
    //TODO:在app中央显示
    m_aboutWindow->move(MainWindow::mutual->geometry().center() - m_aboutWindow->rect().center());
    m_aboutWindow->show();
}

QHBoxLayout* menuModule::initTitleBar(){
    QPushButton* titleIcon = new QPushButton();
    QLabel* titleText = new QLabel();
    m_titleButtonClose = new QToolButton;
    titleIcon->setFixedSize(25,25);
    titleIcon->setIconSize(QSize(25,25));
    titleIcon->setIcon(QIcon::fromTheme("kylin-recorder"));
    titleIcon->setStyleSheet("QPushButton{border:0px;background:transparent;}");
#if DEBUG_MENUMODULE
    iconPath = ":/svg/svg/recording_128.svg";
    appShowingName = "kylin recorder";
#endif
    //TODO：直接从主题调图标，不会QIcon转qpixmap所以暂时从本地拿
    m_titleButtonClose->setFixedSize(30,30);
    m_titleButtonClose->setIcon(QIcon::fromTheme("window-close-symbolic"));
    m_titleButtonClose->setProperty("isWindowButton",0x2);
    m_titleButtonClose->setProperty("useIconHighlightEffect",0x8);
    m_titleButtonClose->setAutoRaise(true);

    connect(m_titleButtonClose,&QPushButton::clicked,[=](){m_aboutWindow->close();});
    QHBoxLayout *hlyt = new QHBoxLayout;
    titleText->setText(tr(m_appShowingName.toLocal8Bit()));
    hlyt->setSpacing(0);
    hlyt->setMargin(4);
    hlyt->addSpacing(4);
    hlyt->addWidget(titleIcon,0,Qt::AlignCenter); //居下显示
    hlyt->addSpacing(8);
    hlyt->addWidget(titleText,0,Qt::AlignCenter);
    hlyt->addStretch();
    hlyt->addWidget(m_titleButtonClose,0,Qt::AlignBottom);
    return hlyt;
}

QVBoxLayout* menuModule::initBody(){
#if DEBUG_MENUMODULE
    appVersion = "2020.01.07";
#endif
    QPushButton* bodyIcon = new QPushButton();
    bodyIcon->setFixedSize(96,96);
    bodyIcon->setIconSize(QSize(96,96));
    bodyIcon->setIcon(QIcon::fromTheme("kylin-recorder", QIcon(m_iconPath)));
    bodyIcon->setStyleSheet("QPushButton{border:0px;background:transparent;}");

    QLabel* bodyAppName = new QLabel();
    bodyAppName->setFixedHeight(32);
    bodyAppName->setText(tr(m_appShowingName.toLocal8Bit()));
    QLabel* bodyAppVersion = new QLabel();
    bodyAppVersion->setFixedHeight(32);
    bodyAppVersion->setText(tr("Version: ") + m_appVersion);
    bodyAppVersion->setAlignment(Qt::AlignLeft);
    m_bodySupport = new QLabel();
    m_bodySupport->setText(tr("Service & Support: ") +
                             "<a href=\"mailto://support@kylinos.cn\""
                             "style=\"color:rgba(0,0,0,1)\">"
                             "support@kylinos.cn</a>");
    m_bodySupport->setOpenExternalLinks(true);
    m_bodySupport->setContextMenuPolicy(Qt::NoContextMenu);//此行为禁用链接右键点击弹出的复制链接的功能
    m_bodySupport->setFixedHeight(28);
    QWidget *bodySupportWidget = new QWidget();
    QHBoxLayout * bodySupportLayout = new QHBoxLayout();
    bodySupportLayout->addWidget(m_bodySupport,0,Qt::AlignHCenter);
    bodySupportLayout->setContentsMargins(25,0,0,0);
    bodySupportWidget->setLayout(bodySupportLayout);

    m_softWareIntroduceLabel = new QTextBrowser();
    m_softWareIntroduceLabel->setFixedSize(380,80);
    m_softWareIntroduceLabel->append(tr("The UI is friendly and easy to operate."
                                    " It supports by microphone"
                                    " ,playing and deleting in file list,"
                                    " and switching between Mini mode and Theme mode"));
    m_softWareIntroduceLabel->setFrameShape(QTextBrowser::NoFrame);
    m_softWareIntroduceLabel->setStyleSheet(".QTextBrowser{background:transparent;}");
    QVBoxLayout *vlyt = new QVBoxLayout;
    vlyt->addWidget(bodyIcon,0,Qt::AlignHCenter);
    vlyt->addWidget(bodyAppName,0,Qt::AlignHCenter);
    vlyt->addWidget(bodyAppVersion,0,Qt::AlignHCenter);
    vlyt->addWidget(m_softWareIntroduceLabel,0,Qt::AlignHCenter);
    vlyt->addWidget(bodySupportWidget,0,Qt::AlignLeft);
    return vlyt;
}

void menuModule::setStyle(){
//    menuButton->setStyleSheet("QPushButton::menu-indicator{image:None;}");
}

void menuModule::initGsetting(){
    if(QGSettings::isSchemaInstalled(FITTHEMEWINDOW)){
        m_pGsettingThemeData = new QGSettings(FITTHEMEWINDOW);
        connect(m_pGsettingThemeData,&QGSettings::changed,this,&menuModule::dealSystemGsettingChange);
    }

}

void menuModule::dealSystemGsettingChange(const QString key){
    if(key == "styleName"){
        refreshThemeBySystemConf();
    }
}

void menuModule::refreshThemeBySystemConf(){
    QString themeNow = m_pGsettingThemeData->get("styleName").toString();
    if("ukui-dark" == themeNow || "ukui-black" == themeNow){
        setThemeDark();
    }else{
        setThemeLight();
    }
}

void menuModule::setThemeDark(){
    qDebug()<<"set theme dark";
    if(m_aboutWindow)
    {
        m_bodySupport->setText(tr("Service & Support: ") +
                             "<a href=\"mailto://support@kylinos.cn\""
                             "style=\"color:rgba(255,255,255,1)\">"
                             "support@kylinos.cn</a>");

        m_pal.setColor(QPalette::Window,QColor(18,18,18));
        m_aboutWindow->setPalette(m_pal);

    }
    emit menuModuleSetThemeStyle("dark-theme");
}

void menuModule::setThemeLight(){
    qDebug()<<"set theme light";
    if(m_aboutWindow)
    {
        m_bodySupport->setText(tr("Service & Support: ") +
                             "<a href=\"mailto://support@kylinos.cn\""
                             "style=\"color:rgba(0,0,0,1)\">"
                             "support@kylinos.cn</a>");
        m_pal.setColor(QPalette::Window,QColor(255,255,255));
        m_aboutWindow->setPalette(m_pal);

    }
    emit menuModuleSetThemeStyle("light-theme");

}
