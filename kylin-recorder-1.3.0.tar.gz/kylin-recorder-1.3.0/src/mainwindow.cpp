/*
 * Copyright (C) 2020, KylinSoft Co., Ltd.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 *  Authors: baijincheng <baijincheng@kylinos.cn>
 */
#include "mainwindow.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QDebug>
#include "QPixmap"
#include <QLabel>
#include <QSlider>
#include <qtextcodec.h>//保存中文路径时用上此头文件
#include <QMessageBox>
#include <QFileDialog>

#include "tools.h"
#include "xatom-helper.h"
#define BufferSize         35280
//const qint64 TIME_TRANSFORM = 1000 * 1000;              // 微妙转秒;
#define rectangleCount 48//矩形条个数

MainWindow *MainWindow::mutual = nullptr;//初始化！！！

MainWindow::MainWindow(QStringList str,QWidget *parent)
    :QWidget(parent)
{
    mutual = this;
    //线程的使用
    m_mainThread = new QThread(this);//主线程
    m_subThread = new MyThread;//子线程不要传参数this
    qDebug()<<"主线程:"<<QThread::currentThread();
    m_subThread->moveToThread(m_mainThread);

    initGsetting();//初始化GSetting配置文件
    checkSingle(str);//检查单例模式
    initDbus();//初始化插拔信号和s3/s4的dbus
    initMainWindow();//初始化主界面
    setTwoPageWindow();//设置第二个页面
    m_mainThread->start();
    MainWindowLayout();//主窗体布局方法
    bindGSetting();//绑定当前GSetting
    currentGSettingChangeUI();//GSetting未变化时用当前的值
    mainWindow_page2(); //必须加上初始化第二个主页面(此函数有两处需要被调用:构造函数+切换页面时)
    updateGsetting_ListWidget();
    //点击关闭时把线程关掉
    connect(m_closeButton,&QToolButton::clicked,[=](){
        m_mainThread->quit();
          m_mainThread->wait();
    });
    //这个分支要放在下面,对于执行命令时有些还没来得及实例化所以要放在后面
    if(!m_argName.isEmpty())
    {
        qDebug()<<"单例参数argName = "<<m_argName;
        int num = m_argName.size();
        switch (num) {
        case 1:
            command_Control(m_argName[0]);
            break;
        default:
            break;
        }
    }
    m_isFirstObject = false;//可以接收外部命令
}

//初步配置文件
void MainWindow::initGsetting()
{
    if (QGSettings::isSchemaInstalled(KYLINRECORDER)){
        m_defaultPathData = new QGSettings(KYLINRECORDER);
    }
    if (QGSettings::isSchemaInstalled(FITTHEMEWINDOW)){
        m_themeData = new QGSettings(FITTHEMEWINDOW);
    }
    if (QGSettings::isSchemaInstalled(FITCONTROLTRANS)) {
        m_pGsettingControlTrans = new QGSettings(FITCONTROLTRANS);
    }
}

void MainWindow::bindGSetting()
{
    if(m_defaultPathData != nullptr){
        connect(m_defaultPathData,&QGSettings::changed,this,&MainWindow::changePathDataSlot);
    }
    if(m_themeData != nullptr)
    {
        connect(m_themeData,&QGSettings::changed,this,&MainWindow::changeThemeColorSlot);
    }
    if(m_pGsettingControlTrans != nullptr)
    {
        connect(m_pGsettingControlTrans,&QGSettings::changed,this,&MainWindow::changeControlTransSlot);
    }

}

void MainWindow::currentGSettingChangeUI()
{
    if(m_defaultPathData != nullptr){
        sourceInput(m_defaultPathData->get("source").toInt());
    }
    if(m_themeData != nullptr){
        themeStyle(m_themeData->get("styleName").toString());
        themeFontStyle(m_themeData->get("systemFont").toString(),m_themeData->get("systemFontSize").toInt());
    }
    if(m_pGsettingControlTrans != nullptr){
        transChange();
    }

}

void MainWindow::changePathDataSlot(const QString &key)
{
    if(key == "source"){

        m_source = m_defaultPathData->get("source").toInt();
        sourceInput(m_source);

    }
}

void MainWindow::changeThemeColorSlot(const QString &key)
{
    if(key == "styleName"){

        m_theme = m_themeData->get("styleName").toString();
        themeStyle(m_theme);
        qDebug()<<"主题颜色:"<<m_theme;

    }
    else if(key == "systemFont"){

        m_fontType = m_themeData->get("systemFont").toString();
        m_fontSize = m_themeData->get("systemFontSize").toInt();
        themeFontStyle(m_fontType,m_fontSize);

    }else if(key == "systemFontSize"){
        m_fontType = m_themeData->get("systemFont").toString();
        m_fontSize = m_themeData->get("systemFontSize").toInt();
        themeFontStyle(m_fontType,m_fontSize);
    }
}

void MainWindow::changeControlTransSlot(const QString &key)
{
    if (key == "transparency") {
//                qDebug()<<"改变了透明度";
        transChange();
    }
}

void MainWindow::initDbus()
{
    // 用户手册功能
    m_DaemonIpcDbus = new DaemonDbus();
    QDBusConnection sessionBus = QDBusConnection::sessionBus();
    if(sessionBus.registerService("org.ukui.kylin_recorder"))
    {
        sessionBus.registerObject("/org/ukui/kylin_recorder",this,
                                  QDBusConnection::ExportAllContents);
        qDebug()<<"初始化DBUS成功";
    }
    else
        qDebug()<<"初始化DBUS失败";
    //S3 S4策略
    QDBusConnection::systemBus().connect(QString("org.freedesktop.login1"),
                                         QString("/org/freedesktop/login1"),
                                         QString("org.freedesktop.login1.Manager"),
                                         QString("PrepareForShutdown"), this,
                                         SLOT(onPrepareForShutdown(bool)));
    QDBusConnection::systemBus().connect(QString("org.freedesktop.login1"),
                                         QString("/org/freedesktop/login1"),
                                         QString("org.freedesktop.login1.Manager"),
                                         QString("PrepareForSleep"), this,
                                         SLOT(onPrepareForSleep(bool)));
    //插拔耳机的3.0信号,考虑到音乐和影音在拔出时发此信号DbusSingleTest,对于录音要停止(两个都不可以注释,否则会出现卡死)
    QDBusConnection::sessionBus().connect(QString(), QString( "/"), "org.ukui.media", "DbusSignalRecorder",this, SLOT(inputDevice_get(QString)));
    QDBusConnection::sessionBus().connect(QString(), QString( "/"), "org.ukui.media", "DbusSingleTest",this, SLOT(inputDevice_get(QString)));
    //插拔输入设备的信号3.1的聲音
    QDBusConnection::sessionBus().connect(QString(), QString( "/"), "org.ukui.media", "sourcePortChanged",this, SLOT(inputDevice_get(QString)));
    //插拔输出设备的信号3.1的聲音
    QDBusConnection::sessionBus().connect(QString(), QString( "/"), "org.ukui.media", "sinkPortChanged",this, SLOT(outputDevice_get(QString)));

}

//初始化主界面
void MainWindow::initMainWindow()
{
    int WIDTH = 800 ;
    int HEIGHT = 460 ;
    this -> installEventFilter(this);
    this -> setFixedSize(WIDTH,HEIGHT);
    this -> setWindowTitle(tr("Recorder"));
    this -> setProperty("useSystemStyleBlur",true);//毛玻璃
    this -> setAttribute(Qt::WA_TranslucentBackground,true);//毛玻璃
    //屏幕中间老方法
    //    this->move((QApplication::desktop()->width() -WIDTH)/2, (QApplication::desktop()->height() - HEIGHT)/2);
    //显示在活动屏幕中间新方法
    QScreen *screen = QGuiApplication::primaryScreen();
    this ->move((screen->geometry().width() - WIDTH) / 2,(screen->geometry().height() - HEIGHT) / 2);

    m_tipWindow = new TipWindow();

    m_titleLeftWidget = new QWidget();
    m_titleRightWidget = new QWidget();

    m_titleWidget = new QWidget();//标题栏Wid
    m_mainLayout = new QVBoxLayout();//主窗体的布局
    m_pStackedWidget = new QStackedWidget();//录音图标和波形图的堆栈Wid
    m_fileListWidget = new QWidget();//列表Wid
    m_leftMainWidget = new QWidget();//主左Wid
    m_rightMainWidget = new QWidget();//主右Wid

    m_firstPageWidget = new QWidget();//初始页面只有一个大按钮
    m_listPageWidget = new QWidget();//含有列表和按钮的页面
    m_centerWidget = new QWidget();//中间Wid
    m_fileListWidgetLayout = new QVBoxLayout();
    m_recordButtonWidget = new QWidget();
    m_titleLeftLayout = new QHBoxLayout();//左标题布局
    m_titleRightLayout = new QHBoxLayout();//右标题布局
    m_titleLayout = new QHBoxLayout();//标题栏布局

    m_leftMainWidLayout = new QHBoxLayout();//主左布局
    m_rightMainWidLayout = new QVBoxLayout();//主右布局

    m_firstPageLayout = new QHBoxLayout();//第一个页面布局
    m_listPageLayout = new QHBoxLayout();//第三个页面布局
    m_centerLayout = new QHBoxLayout();//中间布局

    m_appPicture=new QPushButton(this);//窗体左上角标题图片
    m_appPicture->setIcon(QIcon::fromTheme("kylin-recorder", QIcon(":/png/png/recording_32.png")));
    m_appPicture->setFixedSize(25,25);
    m_appPicture->setIconSize(QSize(25,25));//重置图标大小
    m_appPicture->setStyleSheet("QPushButton{border:0px;border-radius:4px;background:transparent;}");

    m_appLabel=new QLabel(this);
    m_appLabel->setText(tr("Recorder"));//？字体待修改
    m_appLabel->setFixedHeight(24);

    m_menu = new QMenu(this);
    m_actionSet = new QAction(tr("Set"),m_menu);
    m_actionHelp = new QAction(tr("Help"),m_menu);
    m_actionAbout = new QAction(tr("About"),m_menu);

    //(三)按钮及下拉菜单
    m_menuModule = new menuModule(this);
    m_menuModule->m_menuButton->setToolTip(tr("Menu"));
    m_menuModule->m_menuButton->setFixedSize(30,30);
    m_menuModule->m_menuButton->setIcon(QIcon::fromTheme("open-menu-symbolic"));
    m_menuModule->m_menuButton->setAutoRaise(true);
    m_menuModule->m_menuButton->setProperty("isWindowButton", 0x1);
    m_menuModule->m_menuButton->setProperty("useIconHighlightEffect",0x2);
    m_menuModule->m_menuButton->setPopupMode(QToolButton::InstantPopup);//QToolButton必须加上的

    //mini按钮
    m_miniButton = new QToolButton(this);
    m_miniButton->setFixedSize(30,30);
    m_miniButton->setToolTip(tr("Mini"));
    m_miniButton->setProperty("isWindowButton", 0x1);
    m_miniButton->setProperty("useIconHighlightEffect", 0x2);
    m_miniButton->setAutoRaise(true);
    m_miniButton->setIcon(QIcon::fromTheme("ukui-mini"));//主题库的mini图标

    //最小化按钮
    m_minButton = new QToolButton(this);
    m_minButton->setFixedSize(30,30);
    m_minButton->setToolTip(tr("Minimize"));
    m_minButton->setProperty("isWindowButton", 0x1);
    m_minButton->setProperty("useIconHighlightEffect", 0x2);
    m_minButton->setAutoRaise(true);
    m_minButton->setIcon(QIcon::fromTheme("window-minimize-symbolic"));//主题库的最小化图标

    //最大化按钮
//    maxButton = new QToolButton(this);
//    maxButton->setFixedSize(30,30);
//    maxButton->setToolTip(tr("Max"));
//    maxButton->setProperty("isWindowButton", 0x1);
//    maxButton->setProperty("useIconHighlightEffect", 0x2);
//    maxButton->setAutoRaise(true);
//    maxButton->setIcon(QIcon::fromTheme("window-maximize-symbolic"));//主题库的最大化图标，先注释掉否则会在logo后面出现重叠

    //关闭按钮
    m_closeButton = new QToolButton(this);
    m_closeButton->setFixedSize(30,30);
    m_closeButton->setToolTip(tr("Close"));
    m_closeButton->setIcon(QIcon::fromTheme("window-close-symbolic"));//主题库的叉子图标
    m_closeButton->setProperty("isWindowButton", 0x2);
    m_closeButton->setProperty("useIconHighlightEffect", 0x8);
    m_closeButton->setAutoRaise(true);

    m_firstRecordButton = new CustomButton(":/svg/svg/rec-default.svg",
                                         ":/svg/svg/rec-hover.svg",
                                         ":/svg/svg/rec-click.svg",this);
    m_firstRecordButton->setToolTip(tr("Recording"));
    m_firstRecordButton->setFixedSize(128,128);

    m_thirdRecordButton = new CustomButton(":/svg/svg/rec-default.svg",
                                         ":/svg/svg/rec-hover.svg",
                                         ":/svg/svg/rec-click.svg",this);
    m_thirdRecordButton->setToolTip(tr("Recording"));
    m_thirdRecordButton->setFixedSize(128,128);

    connect(m_miniButton,   &QToolButton::clicked, this, &MainWindow::miniShow);//mini窗口
    connect(m_minButton,    &QToolButton::clicked, this, &MainWindow::minShow);//最小化窗口
//    connect(maxButton,    &QToolButton::clicked, this, &MainWindow::maxShow);//最大化窗口
    connect(m_closeButton,  &QToolButton::clicked, this, &MainWindow::closeWindow);//关闭
    connect(m_actionSet,    &QAction::triggered,   this, &MainWindow::goset);//跳转设置界面
    //主界面按钮
    connect(m_firstRecordButton, &QPushButton::clicked, this, &MainWindow::switchPage);//首页按钮绑定
    connect(m_thirdRecordButton, &QPushButton::clicked, this, &MainWindow::switchPage);//第三个页面按钮的绑定
    connect(m_pStackedWidget,&QStackedWidget::currentChanged,this,&MainWindow::monitorStackChanged);
    connect(&m_fileWatcher,&QFileSystemWatcher::fileChanged,this,&MainWindow::monitorFileChanged);

}

void MainWindow::monitorFileChanged(QString dirStr)
{
    qDebug()<<"变化的目录是:"<<dirStr;
    m_nowCount = Tools::getRecordingFileinfos().count();
//    qDebug()<<"此时的preCount:"<<preCount<<"此时的nowCount:"<<nowCount;
    QFileInfoList fileList = Tools::getRecordingFileinfos();

//    if(preCount >= nowCount && nowCount!=0){//文件数量减少时再刷新，重新增加
//        list->disconnect();
//        list->clear();
//        qDebug()<<"此时的preCount:"<<preCount<<"此时的nowCount:"<<nowCount;
//        for(int i = 0 ;i< nowCount;i++)
//        {
//            QString path = fileList.at(i).absoluteFilePath();
//            if(Tools::fileExists(path))
//            {
//                slotListItemAdd(path,i+1);//每当配置文件中有路径时就在list中更新一下
//                isFileNull(nowCount);
//            }
//        }

//    }
//    preCount = nowCount;//一定加上
//    if(nowCount == 0){//注意播放时突然删除要先停止播放
//        list->disconnect();
//        list->clear();
//        qDebug()<<"是否闪退2";
//        isFileNull(0);
//    }


}

void MainWindow::monitorStackChanged(int index)
{
    m_index = index;
    qDebug()<<"当前页面索引:"<<index;
    if(!m_themeData){
        qDebug()<<"从未实例化过，就实例化一次";
        m_themeData = new QGSettings(FITTHEMEWINDOW);
    }
    m_theme = m_themeData->get("styleName").toString();
    if(m_index == 2){
        if(m_theme == "ukui-dark"||m_theme=="ukui-black"){
            m_titleRightColor = ".QWidget{background-color:#121212;}";
        }else{
            m_titleRightColor = ".QWidget{background-color:#FFFFFF;}";
        }
    }else{
        m_titleRightColor = "";
    }
    m_titleRightWidget->setStyleSheet(m_titleRightColor);

}

//设置第二个页面
void MainWindow::setTwoPageWindow()
{

    //第二个页面的控件初始化
    m_realTimer = new QTimer;//定时器,用来记录
    m_delayTimer = new QTimer;//QTimer不可以在线程的构造函数里
    m_showTimeLabel = new QLabel(this);

    m_finishButton = new CustomButton(":/svg/svg/finish-defalut-light.svg",
                                 ":/svg/svg/finish-hover.svg",
                                 ":/svg/svg/finish-click.svg",this);
    m_finishButton->setFixedSize(56,56);
    m_finishButton->setToolTip(tr("Finish"));

    m_pauseButton = new CustomButton(":/svg/svg/pause-light.svg",
                                   ":/svg/svg/pause-hover.svg",
                                   ":/svg/svg/pause-click.svg",this);

    m_pauseButton->setFixedSize(56,56);
    m_continueButton = new CustomButton(":/svg/svg/continue-light.svg",
                                      ":/svg/svg/continue-hover.svg",
                                      ":/svg/svg/continue-click.svg");
    m_continueButton->setFixedSize(56,56);

    m_pageTwoWid = new QWidget(this);//第二个页面wid
    m_showTimelbWid = new QWidget(this);//时间wid
    m_waveWidget = new QWidget(this);//波形图wid
    m_controlPlayAndPauseWid = new QWidget(this);

    m_showTimelbLayout = new QHBoxLayout();
    m_controlPlayAndPauseLayout = new QHBoxLayout();
    m_pageTwoLayout = new QVBoxLayout();
    m_mpvPlayer = new MMediaPlayer;//mpv播放组件
    m_playList = new QMediaPlaylist;//播放列表


    //主界面右侧listWidget
    m_fileListTitleLabel=new QLabel(this);
    m_fileListTitleLabel->setText(tr("File List"));

    m_fileListTitleLabelWidget = new QWidget();
    m_fileListTitleLabelLayout = new QHBoxLayout();
    m_zeroFileMessageLabel = new QLabel(this);

    m_seatLabel=new QLabel(this);
    m_seatLabel->setText("  ");//占位

    m_list = new QListWidget(this);
    m_list->installEventFilter(this);//安装事件过滤器
    m_list->setSortingEnabled(true);
    m_list->sortItems(Qt::DescendingOrder);
    m_list->setViewMode(QListView::ListMode);
    m_list->setFrameShape(QListWidget::NoFrame);//去掉list的边框
    m_list->verticalScrollBar()->setStyleSheet(".QScrollBar{width:8px;}");//设置整个滑动条宽度
    m_list->setStyleSheet(".QListWidget::item:hover{background:transparent;}");
    m_list->setSelectionMode(QAbstractItemView::NoSelection);//list取消原装的选中功能
    fileWatcher = new QFileSystemWatcher(this);
//    fileWatcher->addPath(Tools::getRecordingSaveDirectory());


    connect(m_delayTimer, &QTimer::timeout,m_subThread,&MyThread::fun);
    connect(this,    &MainWindow::startRecord, m_subThread, &MyThread::record_pressed);
    connect(m_subThread,&MyThread::recordPaint,       this, &MainWindow::recordPaint);//绘波形图
    connect(m_subThread,&MyThread::changeVoicePicture,this, &MainWindow::changeVoicePicture);
    connect(this,    &MainWindow::stopRecord,  m_subThread, &MyThread::stopBtnPressed);
    connect(this,    &MainWindow::playRecord,  m_subThread, &MyThread::playRecord);
    connect(this,    &MainWindow::pauseRecord, m_subThread, &MyThread::pauseRecord);

    connect(m_realTimer,       &QTimer::timeout,         this,  &MainWindow::updateDisplay);
    connect(m_finishButton,&QToolButton::clicked,       this,  &MainWindow::stop_clicked);
    connect(m_pauseButton,&QPushButton::clicked, this,  &MainWindow::play_pause_clicked);
    connect(m_continueButton,&QPushButton::clicked, this,  &MainWindow::play_pause_clicked);

}

int MainWindow::command_Control(QString cmd1)
{
    qDebug()<<"命令:"<<cmd1;
    //990需求命令行控制
    if(m_isFirstObject&&!QFileInfo::exists(cmd1))//首个实例不接受文件以外的参数
    {
        if(cmd1 == "-c"||cmd1 =="-close")
        {
            qDebug()<<"-c"<<cmd1;
            this->close();
            exit(0);
        }
        qDebug()<<"首个实例不接受文件以外的参数"<<cmd1;
        m_isFirstObject = false;//可以接收其他命令
        return 0;
    }
    if(cmd1=="")//无参数，单例触发
    {
        //kwin接口唤醒
        KWindowSystem::forceActiveWindow(this->winId());
        qDebug()<<"窗口置顶";
        return 0;
    }
    if(cmd1=="-s"||cmd1=="-start")//开始录音
    {
        //------录音------
        qDebug()<<"isRecording = "<<m_isRecording<<" "<<m_stratOrPause;
        if(!m_isRecording&&!m_stratOrPause)
        {
            qDebug()<<"可以录音";
            switchPage();
        }
        return 0;
    }
    if(cmd1=="-p"||cmd1=="-pause")//暂停
    {
        //------暂停------
        if(m_isRecording)
        {
            qDebug()<<m_isRecording<<" "<<m_stratOrPause;
            qDebug()<<"录音暂停";
            play_pause_clicked();//检测到正在录音时才可以暂停录制
        }
        else
        {
            if(m_stratOrPause)//因为暂停录音时strat_pause会置true
            {
                play_pause_clicked();//开始录制
            }
        }
        return 0;
    }
    if(cmd1=="-f"||cmd1=="-finish")//结束录音
    {
        qDebug()<<"isRecording = "<<m_isRecording<<"strat_pause = "<<m_stratOrPause;
        if(m_isRecording||m_stratOrPause)
        {
            qDebug()<<"可以结束";
            stop_clicked();
        }
        return 0;
    }
    if(cmd1=="-c"||cmd1=="-close")//结束录音
    {
        m_mainThread->quit();
        m_mainThread->wait();
        this->close();
        m_miniWindow.close();
        return 0;
    }
    QStringList qStringListPath;
    qStringListPath << cmd1;
    processArgs(qStringListPath);
    return 0;//重要:int类型的函数一定要加返回值
}

//对于台式机，可以收到耳机插拔输入设备的DBus信号
void MainWindow::inputDevice_get(QString str)
{
    qDebug()<<"輸入設備插拔";

    QAudioDeviceInfo inputDevice(QAudioDeviceInfo::defaultInputDevice());
    if(inputDevice.deviceName().contains("monitor")){
        if(m_source == 2){
            m_firstRecordButton->setButtonEnabled(true,false);
            m_thirdRecordButton->setButtonEnabled(true,false);
            m_miniWindow.m_miniRecordButton->setButtonEnabled(true,true);
        }else{
            stop_clicked();
            m_firstRecordButton->setButtonEnabled(false,false);
            m_thirdRecordButton->setButtonEnabled(false,false);
            m_miniWindow.m_miniRecordButton->setButtonEnabled(false,true);
        }
    }else{
        if(m_source == 1){
            stop_clicked();
        }
        qDebug()<<"inputDevice:"<<inputDevice.deviceName();
        m_firstRecordButton->setButtonEnabled(true,false);
        m_thirdRecordButton->setButtonEnabled(true,false);
        m_miniWindow.m_miniRecordButton->setButtonEnabled(true,true);

    }

}

void MainWindow::outputDevice_get(QString str)
{
    qDebug()<<"輸出設備插拔";
    if(m_source == 2){
        stop_clicked();
    }else{

    }

}

void MainWindow::onPrepareForShutdown(bool Shutdown)
{
    //目前只做事件监听，不处理
    qDebug()<<"onPrepareForShutdown"<<Shutdown;
}

//监听系统睡眠信号
void MainWindow::onPrepareForSleep(bool isSleep)
{
    //990
    //空指针检验
    //------此处空指针校验（如果用了指针）------
    //系统事件
    if(isSleep)//睡眠分支
    {
        qDebug()<<"睡眠！！！";
        if(m_isRecording)
        {
            stop_clicked();
//            play_pause_clicked();//检测到睡眠时要暂停录制

        }
    }
    else//唤醒分支
    {
        qDebug()<<"唤醒！！！";
//        if(!isRecording)//如果没有录音则走此分支
//        {
//            if(strat_pause)//因为暂停录音时strat_pause会置true
//            {
//                play_pause_clicked();//检测到唤醒时要开始录制

//            }
//            //一种情况是压根就没开始录制他就睡眠了。因此就不会做其他事情
//        }
    }
}

void MainWindow::handlingSlot()
{
//    WrrMsg = new QMessageBox(QMessageBox::Warning, tr("Warning"), tr("Transcoding..."),QMessageBox::Yes);
//    WrrMsg->button(QMessageBox::Yes)->setText(tr("OK"));
//    WrrMsg->exec();


    m_tipWindow->move(this->geometry().center() - m_tipWindow->rect().center());
    m_tipWindow->show();
    QCoreApplication::processEvents(QEventLoop::ExcludeUserInputEvents,100);//防止界面假死

    qDebug()<<"接收到界面消息!";

}

void MainWindow::closeWindow()
{
    if(m_mainThread->isRunning()){
        m_mainThread->quit();
        m_mainThread->wait();
        this->close();
        m_miniWindow.close();
    }


}

// 实现键盘响应
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    // F1快捷键打开用户手册
    if (event->key() == Qt::Key_F1) {
        if (!m_DaemonIpcDbus->daemonIsNotRunning()){
            //F1快捷键打开用户手册，如kylin-recorder
            //由于是小工具类，下面的showGuide参数要填写"kylin-recorder"
            m_DaemonIpcDbus->showGuide("kylin-recorder");
        }
    }
}

MainWindow::~MainWindow()
{
    qDebug()<<"析构MainWindow";
    QList<FileItem*> List = this->findChildren<FileItem*>();
    for(FileItem* item:List)
    {
        item->deleteLater();
    }
    QList<myWave*> list = this->findChildren<myWave*>();
    for(myWave* tmp:list)
    {
        tmp->deleteLater();
    }
    m_tipWindow->deleteLater();
    if(m_subThread != nullptr){
        if(m_mainThread->isRunning()){
            qDebug()<<"关闭还在运行的线程";
            m_mainThread->quit();
            m_mainThread->wait();
        }
        //delete myThread; // 最后有没有都行！
    }
    m_DaemonIpcDbus->deleteLater();
}

void MainWindow::isFileNull(int n)
{

    if(n == 0)
    {
        qDebug()<<"文件个数："<<n;
        m_zeroFileMessageLabel->setParent(m_fileListWidget);
        m_zeroFileMessageLabel->show();
        m_pStackedWidget->setCurrentIndex(0);
//        defaultPathData->set("samefilenum",1);//列表里无文件时归1
    }
    else
    {

        m_pStackedWidget->setCurrentIndex(2);
        m_zeroFileMessageLabel->hide();
    }
}

void MainWindow::MainWindowLayout()
{

    m_zeroFileMessageLabel->setFixedSize(200,50);
    m_zeroFileMessageLabel->setText(tr("None of the Recording File"));//列表无录音文件时
    m_zeroFileMessageLabel->move((m_fileListWidget->width()-m_zeroFileMessageLabel->width()/2)/3,(m_fileListWidget->height()-m_zeroFileMessageLabel->height()/3)/3);

    m_fileListTitleLabelLayout->addWidget(m_fileListTitleLabel);
    m_fileListTitleLabelLayout->setContentsMargins(31,0,0,0);//31,0,0,0改为31,0,0,10即不多不少显示6个
    m_fileListTitleLabelWidget->setLayout(m_fileListTitleLabelLayout);

    m_fileListWidgetLayout->addWidget(m_fileListTitleLabelWidget);
    m_fileListWidgetLayout->addWidget(m_list);
    m_fileListWidgetLayout->setContentsMargins(0,0,0,0);
    m_fileListWidgetLayout->setSpacing(0);
    m_fileListWidget->setLayout(m_fileListWidgetLayout);

    m_titleLeftLayout->addWidget(m_appPicture);
    m_titleLeftLayout->addWidget(m_appLabel);
    m_titleLeftLayout->setSpacing(8);//内部按钮间距8px
    m_titleLeftLayout->setContentsMargins(8,8,0,0);
    m_titleLeftWidget->setLayout(m_titleLeftLayout);
    m_titleLeftWidget->setFixedWidth(308);

    m_titleRightLayout->addWidget(m_seatLabel);//占位用的lb
    m_titleRightLayout->addWidget(m_menuModule->m_menuButton);
    m_titleRightLayout->addWidget(m_miniButton);
    m_titleRightLayout->addWidget(m_minButton);
//    titleRightLayout->addWidget(maxButton);//2020.11.20禁止最大化功能
    m_titleRightLayout->addWidget(m_closeButton);
    m_titleRightLayout->setSpacing(4);//内部按钮间距4px
    m_titleRightLayout->setContentsMargins(0,4,4,0);
    m_titleRightWidget->setLayout(m_titleRightLayout);

    m_titleLayout->addWidget(m_titleLeftWidget);
    m_titleLayout->addWidget(m_titleRightWidget);
    m_titleLayout->setSpacing(0);
    m_titleLayout->setContentsMargins(0,0,0,0);
    m_titleWidget->setLayout(m_titleLayout);

    m_recordButtonLayout = new QVBoxLayout();
    m_recordButtonLayout->addWidget(m_thirdRecordButton,0,Qt::AlignCenter);//录音按钮所在Wid
    m_recordButtonLayout->setContentsMargins(0,0,0,0);
    m_recordButtonWidget->setLayout(m_recordButtonLayout);

    m_pStackedWidget->addWidget(m_firstPageWidget);
    m_pStackedWidget->addWidget(m_pageTwoWid);
    m_pStackedWidget->addWidget(m_listPageWidget);

    m_leftMainWidLayout->addWidget(m_recordButtonWidget,0,Qt::AlignCenter);
    m_leftMainWidLayout->setContentsMargins(30,0,0,30);//间距30看起来就比较居中
    m_leftMainWidget->setLayout(m_leftMainWidLayout);
    m_leftMainWidget->setFixedWidth(308);//sp2的leftMain宽度

    m_rightMainWidLayout->addWidget(m_fileListWidget);
    m_rightMainWidLayout->setSpacing(0);
    m_rightMainWidLayout->setMargin(0);
    m_rightMainWidget->setLayout(m_rightMainWidLayout);

    m_firstPageLayout->addWidget(m_firstRecordButton,0,Qt::AlignCenter);//录音按钮所在Wid
    m_firstPageLayout->setContentsMargins(0,0,0,30);//间距30看起来就比较居中
    m_firstPageWidget->setLayout(m_firstPageLayout);

    m_listPageLayout->addWidget(m_leftMainWidget);
    m_listPageLayout->addWidget(m_rightMainWidget);
    m_listPageLayout->setSpacing(0);
    m_listPageLayout->setContentsMargins(0,0,0,0);
    m_listPageWidget->setLayout(m_listPageLayout);

    m_mainLayout->addWidget(m_titleWidget);
    m_mainLayout->addWidget(m_pStackedWidget);
    m_mainLayout->setSpacing(0);
    m_mainLayout->setContentsMargins(0,0,0,0);
    this->setLayout(m_mainLayout);

}

//最小化
void MainWindow::minShow()
{
    this->showMinimized();
    this->showNormal();//一定要加,防止点击最小化时，依次点击mini再点击复原导致原窗口不显示而还在任务栏
}

//mini模式
void MainWindow::miniShow()
{
    m_miniWindow.showNormal();
    m_miniWindow.activateWindow();
    this->hide();
}

void MainWindow::maxShow()
{
    if(m_isMax)
    {
        this->showNormal();
        m_isMax = false;
    }
    else
    {
        this->showFullScreen();
        m_isMax = true;
    }

}
void MainWindow::themeWindow(QString themeColor)
{
    if(themeColor == "ukui-dark"||themeColor=="ukui-black")
    {
        //主界面
        this->setObjectName("mainWid");//设置命名空间
        //设置界面
        m_setWindow.m_mainWidget->setObjectName("setMainWid");//设置命名空间
        m_setWindow.m_mainWidget->setStyleSheet("#setMainWid{background-color:#131314;}");//自定义窗体(圆角+背景色)
        m_rightMainWidget->setStyleSheet(".QWidget{background-color:#121212;}");
        if(m_index == 2){
            m_titleRightColor = ".QWidget{background-color:#121212;}";
        }else{
            m_titleRightColor = "";
        }
        m_titleRightWidget->setStyleSheet(m_titleRightColor);
    }
    else
    {
        //三联好使了
        m_rightMainWidget->setStyleSheet(".QWidget{background-color:#FFFFFF;}");
        if(m_index == 2){
            m_titleRightColor = ".QWidget{background-color:#FFFFFF;}";
        }else{
            m_titleRightColor = "";
        }
        m_titleRightWidget->setStyleSheet(m_titleRightColor);
        //设置界面
        m_setWindow.m_mainWidget->setObjectName("setMainWid");//设置命名空间
        m_setWindow.m_mainWidget->setStyleSheet("#setMainWid{background-color:#FFFFFF;}");//自定义窗体(圆角+背景色)
        //设置界面
        this->setObjectName("mainWid");//设置命名空间
    }
}
void MainWindow::themeButton(QString themeColor)
{
    if(themeColor == "ukui-dark"||themeColor=="ukui-black")
    {
        changeContinuePauseBtnThemeColor(m_themeData->get("style-name").toString());
        m_miniWindow.changeMiniCoutinuePauseBtnThemeColor(themeColor);
        m_miniWindow.m_miniCloseButton->setIcon(QIcon(":/svg/svg/dark-window-close.svg"));
        m_zeroFileMessageLabel->setStyleSheet("font-size:14px;color:#FFFFFF");
        //关闭按钮
        m_closeButton->setFixedSize(30,30);

        m_finishButton->setStyleSheet( "QToolButton{border-radius:28px;}"
                                  "QToolButton{image: url(:/svg/svg/finish-defalut-light.svg);}"
                                  "QToolButton:hover{image: url(:/svg/svg/finish-hover.svg);}"
                                  "QToolButton:pressed{image: url(:/svg/svg/finish-click.svg);}");
        m_finishButton->setImagePath(":/svg/svg/finish-defalut-dark.svg",
                              ":/svg/svg/finish-hover.svg",
                              ":/svg/svg/finish-click.svg");

    }
    else
    {
        changeContinuePauseBtnThemeColor(m_themeData->get("style-name").toString());
        m_miniWindow.changeMiniCoutinuePauseBtnThemeColor(themeColor);
        m_miniWindow.m_miniCloseButton->setIcon(QIcon::fromTheme("window-close-symbolic"));
        m_zeroFileMessageLabel->setStyleSheet("font-size:14px;color:#404040");
        //设置按钮

        m_finishButton->setImagePath(":/svg/svg/finish-defalut-light.svg",
                              ":/svg/svg/finish-hover.svg",
                              ":/svg/svg/finish-click.svg");     
    }

}
//ffmpeg计算时长
QString MainWindow::playerTotalTime(QString filePath)
{
    FFUtil fu;
    fu.open(filePath);
    int t_duration = fu.getDuration(filePath);
//    qDebug()<<"t_duration"<<t_duration;
    QFile file(filePath);
    qint64 fileSize;
    qint64 time;

    QString durLength;
    fileSize = file.size();

    if(t_duration/1000>30000){
        qDebug()<<"ffmpeg计算出错,用文件大小计算";
        time = fileSize/64000;
        QTime totalTime(time/3600,(time%3600)/60,time%60);
        durLength=totalTime.toString("hh:mm:ss");
    }else{
//        qDebug()<<"ffmpeg解析正确";
        durLength = Tools::formatMillisecond(t_duration);
    }
//    qDebug()<<"时长:"<<durLength<<"长度:"<<t_duration;
    file.close();
    return durLength;
}



void MainWindow::themeFontStyle(QString fontType, int fontSize)
{
    int side = 18*fontSize/15;
    QFont font(fontType,side);
    font.setBold(true);
    m_fileListTitleLabel->setFont(font);

    if(fontSize<=15){
        qDebug()<<"字体类型:"<<fontType<<"字体大小:"<<fontSize;
        QFont fontStyle(fontType,fontSize);
        m_appLabel->setFont(fontStyle);
        m_menuModule->m_softWareIntroduceLabel->setFont(fontStyle);
        m_menuModule->m_bodySupport->setFont(fontStyle);
        m_setWindow.m_setWindowLabel->setFont(fontStyle);
        m_setWindow.m_storeLabel->setFont(fontStyle);
        m_setWindow.m_pathLabel->setFont(fontStyle);
        m_setWindow.m_formatLabel->setFont(fontStyle);
        m_setWindow.m_formatDownList->setFont(fontStyle);
        m_setWindow.m_sourceLabel->setFont(fontStyle);
        m_setWindow.m_sourceDownList->setFont(fontStyle);
        m_setWindow.m_alterButton->setFont(fontStyle);
        emit itemFontStyleSignal(fontStyle);//改变itemswindow字体

    }else{
        qDebug()<<"字体大小最大为15";
        QFont fontStyleLimit(fontType,15);
        m_appLabel->setFont(fontStyleLimit);
        m_menuModule->m_softWareIntroduceLabel->setFont(fontStyleLimit);
        m_menuModule->m_bodySupport->setFont(fontStyleLimit);
        m_setWindow.m_setWindowLabel->setFont(fontStyleLimit);
        m_setWindow.m_storeLabel->setFont(fontStyleLimit);
        m_setWindow.m_pathLabel->setFont(fontStyleLimit);
        m_setWindow.m_formatLabel->setFont(fontStyleLimit);
        m_setWindow.m_formatDownList->setFont(fontStyleLimit);
        m_setWindow.m_sourceLabel->setFont(fontStyleLimit);
        m_setWindow.m_sourceDownList->setFont(fontStyleLimit);
        m_setWindow.m_alterButton->setFont(fontStyleLimit);
        emit itemFontStyleSignal(fontStyleLimit);//改变itemswindow字体
    }

}

void MainWindow::sourceInput(int index)
{
    m_source = m_defaultPathData->get("source").toInt();
    QAudioDeviceInfo inputDevice(QAudioDeviceInfo::defaultInputDevice());
    if(inputDevice.deviceName().contains("monitor")){
        if(index == 1){
            m_firstRecordButton->setButtonEnabled(false,false);
            m_thirdRecordButton->setButtonEnabled(false,false);
            m_miniWindow.m_miniRecordButton->setButtonEnabled(false,true);
            QMessageBox::warning(this,
                                 tr("Warning"),tr("No input device detected!"),QMessageBox::Ok);
        }else{
            m_firstRecordButton->setButtonEnabled(true,false);
            m_thirdRecordButton->setButtonEnabled(true,false);
            m_miniWindow.m_miniRecordButton->setButtonEnabled(true,true);
        }

    }else {
        m_firstRecordButton->setButtonEnabled(true,false);
        m_thirdRecordButton->setButtonEnabled(true,false);
        m_miniWindow.m_miniRecordButton->setButtonEnabled(true,true);
    }

}

void MainWindow::themeStyle(QString themeColor)
{
    qDebug()<<"主题颜色"<<themeColor;
    themeButton(themeColor);//控件类切换
    themeWindow(themeColor);//窗体类切换
}

void MainWindow::checkSingle(QStringList path)//检查单例模式
{
    QString str;
    if(path.size() > 1)
    {
        str = path[1];
    }

    QStringList homePath = QStandardPaths::standardLocations(QStandardPaths::HomeLocation);
    //兼容VNC的单例模式
    QString lockPath = homePath.at(0) + "/.config/kylin-recorder-lock";
    int fd = open(lockPath.toUtf8().data(), O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        exit(1);
    }
    if (lockf(fd, F_TLOCK, 0)) {

         QDBusInterface interface( "org.ukui.kylin_recorder", "/org/ukui/kylin_recorder","org.ukui.kylin_recorder",
                                   QDBusConnection::sessionBus());
         if(path.size() == 1)
             interface.call( "command_Control", str);
         if(path.size() == 2)
             interface.call( "command_Control", str);

        qDebug()<<"Can't lock single file, kylin-recorder is already running!";
        exit(0);

    }
    m_isFirstObject = true;//我是首个对象
    m_argName << str;
    qDebug()<<"单例参数argName:"<<m_argName<<"str:"<<str<<"path:"<<path;

}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton){
        this->m_isPress = true;
        this->winPos = this->pos();
        this->dragPos = event->globalPos();
        event->accept();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    this->m_isPress = false;
    this->setCursor(Qt::ArrowCursor);

}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if(this->m_isPress)//鼠标按压时移动
    {
        this->move(this->winPos - (this->dragPos - event->globalPos()));
        this->setCursor(Qt::ClosedHandCursor);
        event->accept();
    }
}

void MainWindow::changeContinuePauseState(bool isContinue)
{
    if(isContinue){
        m_controlPlayAndPauseLayout->removeWidget(m_continueButton);
        m_continueButton->setParent(NULL);
        m_controlPlayAndPauseLayout->insertWidget(1,m_pauseButton);
        m_pauseButton->setToolTip(tr("pause"));
    }else{
        m_controlPlayAndPauseLayout->removeWidget(m_pauseButton);
        m_pauseButton->setParent(NULL);
        m_controlPlayAndPauseLayout->insertWidget(1,m_continueButton);
        m_continueButton->setToolTip(tr("start"));
    }
}
//按照主题颜色切换改变继续和暂停按钮
void MainWindow::changeContinuePauseBtnThemeColor(QString themeColor)
{
    if(themeColor == "ukui-dark"||themeColor == "ukui-black"){

        m_pauseButton->setImagePath(":/svg/svg/pause-dark.svg",
                                  ":/svg/svg/pause-hover.svg",
                                  ":/svg/svg/pause-click.svg");
        m_continueButton->setImagePath(":/svg/svg/continu-dark.svg",
                                     ":/svg/svg/continue-hover.svg",
                                     ":/svg/svg/continue-click.svg");
    }else{
        m_pauseButton->setImagePath(":/svg/svg/pause-light.svg",
                                  ":/svg/svg/pause-hover.svg",
                                  ":/svg/svg/pause-click.svg");
        m_continueButton->setImagePath(":/svg/svg/continue-light.svg",
                                     ":/svg/svg/continue-hover.svg",
                                     ":/svg/svg/continue-click.svg");

    }
}

//开始和暂停
void MainWindow::play_pause_clicked()
{
    static QTime pauseTime;
    if(m_stratOrPause)
    {

        if(PlayControl::getInstance().getAudioState() == QMediaPlayer::PlayingState){
            QMessageBox::warning(this,tr("Warning"),
                                 tr("Audio is playing, please stop and record again!"));
            return ;
        }
        m_isRecording = true;//开始时正在录音的标记值为true,其为true时禁止Item的悬浮特效
        changeContinuePauseState(m_isRecording);
        changeContinuePauseBtnThemeColor(m_themeData->get("style-name").toString());
        m_miniWindow.changeMiniContinuePauseState(m_isRecording);
        m_miniWindow.changeMiniCoutinuePauseBtnThemeColor(m_themeData->get("style-name").toString());
        emit playRecord();

        m_diffValueTime = QTime::currentTime();//记录开始时的时间
        int t = pauseTime.secsTo(m_diffValueTime);//点击暂停时时间与点击恢复计时的时间差值
        m_baseTime = m_baseTime.addSecs(t);
        m_realTimer->start(100);
        m_miniWindow.m_miniBaseTime = m_miniWindow.m_miniBaseTime.addSecs(t);
        m_miniWindow.m_miniStartOrPause = false;
        m_stratOrPause = false;
    }
    else
    {
        qDebug()<<"pause录音";
        m_isRecording = false;//暂停时正在录音的标记值为false,其为false时Item的悬浮特效可以被开启
        changeContinuePauseState(m_isRecording);
        changeContinuePauseBtnThemeColor(m_themeData->get("style-name").toString());
        m_miniWindow.changeMiniContinuePauseState(m_isRecording);
        m_miniWindow.changeMiniCoutinuePauseBtnThemeColor(m_themeData->get("style-name").toString());
        emit pauseRecord();
        m_realTimer->stop();
        pauseTime = QTime::currentTime();//记录一下当前暂停时的时间
        qDebug()<<pauseTime;
        m_miniWindow.m_miniStartOrPause = true;
        m_stratOrPause = true;
    }

}


void MainWindow::recordPaint(int value)
{
    m_maxNum.prepend(value/100);//将元素插入到Vector的开始
    m_maxNum = m_maxNum.mid(0,rectangleCount);
    for(int i = 0;i<rectangleCount;i++)
    m_customWave.at(i)->setValue(m_maxNum.at(i));
}

void MainWindow::stop_clicked()//停止按钮
{
    if(m_finish)
    {
        m_isRecording = false;//停止录音时此值为false,其为false时Item的悬浮特效可以被开启
        emit stopRecord();
        m_realTimer->stop();//计时停止
        m_delayTimer->stop();
        if(m_stratOrPause)
        {
            m_stratOrPause = false;
            m_miniWindow.m_miniStartOrPause = false;
        }
        //停止按钮触发后的界面
        m_showTimeLabel->setText("00:00:00");//主界面计时停止
        m_miniWindow.m_miniTimeLabel->setText("00:00:00");//mini模式计时停止
        QString systemFont = m_themeData->get("systemFont").toString();
        int systemFontSize = m_themeData->get("systemFontSize").toInt();
        QFont fontStyle(systemFont,systemFontSize);
        qDebug()<<"systemFont"<<systemFont<<"systemFontSize"<<systemFontSize;
        emit itemFontStyleSignal(fontStyle);//改变FileItem字体
        m_finish=false;
        if(m_pStackedWidget->currentIndex() == 0){
            m_pStackedWidget->setCurrentIndex(0);
        }else if(m_pStackedWidget->currentIndex() == 2){
            m_pStackedWidget->setCurrentIndex(2);
        }
        m_miniWindow.m_recordStackedWidget->setCurrentIndex(0);
        m_timeTag = 0;//只有在停止时让计时归零
    }

}

//定时器启动时调用此函数
void MainWindow::updateDisplay()
{

//    1.点击开始后获取到当前的时间并且赋值给baseTime
//    2.启动定时器,间隔1s
//    3.槽函数中再次获取当前的时间currTime
//    4.计算两个时间的差值t
//    5.声明一个showTime对象给他加上t的差值
//    6.格式化后设置显示
    emit m_miniWindow.timeDisplay();
    QTime currTime = QTime::currentTime();
    int t = this->m_baseTime.secsTo(currTime);
    QTime showTime(0,0,0);
    showTime = showTime.addSecs(t);
    this->m_timeStr = showTime.toString("hh:mm:ss");
//    qDebug()<<"秒："<<showTime.second();
    m_timeTag = showTime.minute();
    this->m_showTimeLabel->setText(m_timeStr);
}

void MainWindow::mainWindow_page2()
{
    m_maxNum.clear();
    for(int i=0;i<rectangleCount;i++)m_maxNum.append(0);
    m_pauseButton->setEnabled(true);//按下后，开始录音可以按暂停
    changeContinuePauseBtnThemeColor(m_themeData->get("style-name").toString());
    m_miniWindow.changeMiniCoutinuePauseBtnThemeColor(m_themeData->get("style-name").toString());

    m_showTimeLabel->setText("00:00:00");
    m_showTimeLabel->setStyleSheet("font: bold; font-size:30px;");


    m_showTimelbLayout->addWidget(m_showTimeLabel,0,Qt::AlignCenter);//在布局的中央
    m_showTimelbWid->setLayout(m_showTimelbLayout);
    m_showTimelbWid->setFixedHeight(45);
    m_monitorWaveLayout=new QHBoxLayout();//波形图所在的布局
    for (int i=0;i<rectangleCount;i++)//频率直方图
    {
        myWave *wave=new myWave(false,this);//每次都要初始化一个矩形框
//        wave=new myWave(this);
//        wave->setMaximumHeight(100);
        wave->setRange(0,100);
        m_customWave.push_back(wave);
        m_monitorWaveLayout->addWidget(wave);

    }
    m_monitorWaveLayout->setSpacing(2);
    m_waveWidget->setLayout(m_monitorWaveLayout);
    m_waveWidget->setFixedHeight(100);

    m_controlPlayAndPauseLayout->addWidget(m_finishButton);
    m_controlPlayAndPauseLayout->addWidget(m_pauseButton);
//    controlPlayAndPauseLayout->removeWidget(continueButton);//切换至录音时要先去除continueButton所在wid
    m_controlPlayAndPauseWid->setLayout(m_controlPlayAndPauseLayout);
    m_controlPlayAndPauseWid->setFixedHeight(64);

    m_pageTwoLayout->addWidget(m_showTimelbWid);
    m_pageTwoLayout->addWidget(m_waveWidget);
    m_pageTwoLayout->addWidget(m_controlPlayAndPauseWid);
    m_pageTwoLayout->setContentsMargins(248,60,248,108);

    m_pageTwoWid->setLayout(m_pageTwoLayout);
}

//与堆叠布局搭配使用效果更佳
void MainWindow::switchPage()
{

    qDebug()<<"播放状态*********************"<<PlayControl::getInstance().getAudioState();
    if(PlayControl::getInstance().getAudioState() != QMediaPlayer::PlayingState)//判断是否有音频在播放，若无音频播放则可以录音
    {
        m_finish=true;//stop按钮默认是true代表停止中
        m_isRecording = true;//正在录音时此标记为true，此为true时悬浮特效被禁止,这一行一定要在前面
        m_pStackedWidget->setCurrentIndex(1);
        m_miniWindow.m_recordStackedWidget->setCurrentIndex(1);//切换至录音按钮
        /*
         *修复波形图刷新异常问题;
         * */
        for (int i=0;i<rectangleCount;i++)//频率直方图
        {
            if(m_customWave.at(i) != nullptr){
                m_customWave.at(i)->setValue(0);
            }
        }
        emit startRecord();
        if(m_source == 1){
            //如果是麦克风则弹窗提示
            showNotify(tr("Tips From Recorder"));
        }

        m_delayTimer->start(150);//每隔xms检测一次，波形图缓慢刷新S
        m_realTimer->start(100);
        changeContinuePauseState(m_isRecording);
        m_miniWindow.changeMiniContinuePauseState(m_isRecording);
        mainWindow_page2();//必须加
        //刚开始点击按钮时才可以开启定时器
        m_baseTime = m_baseTime.currentTime();
        m_miniWindow.m_miniBaseTime = m_miniWindow.m_miniBaseTime.currentTime();
    }
    else
    {
        QMessageBox::warning(this,tr("Warning"),
                             tr("Audio is playing, please stop and record again!"));

        return ;
    }

}

void MainWindow::changeVoicePicture()
{
}

void MainWindow::goset()
{

    m_setWindow.m_mainWidget->show();
    m_setWindow.m_mainWidget->move(this->geometry().center() - m_setWindow.m_mainWidget->rect().center());
//    if(isRecording||strat_pause)
//    {
//        qDebug()<<"可以结束";
//        stop_clicked();
//    }
    if(m_isRecording||m_stratOrPause){
        m_setWindow.m_alterButton->setEnabled(false);
        m_setWindow.m_formatDownList->setEnabled(false);
        m_setWindow.m_sourceDownList->setEnabled(false);

    }else{
        m_setWindow.m_alterButton->setEnabled(true);
        m_setWindow.m_formatDownList->setEnabled(true);
        m_setWindow.m_sourceDownList->setEnabled(true);
    }

}

void MainWindow::updateGsetting_ListWidget()//初始化时配置文件刷新出,传""时为应用开始时的刷新
{
    qDebug() <<"刷新文件列表";
    m_list->clear();
    QStringList filters;
    filters << "*.raw";
    QString str = QStandardPaths::writableLocation(QStandardPaths::HomeLocation);
    QDir tempRawFileDir = str + "/.cache";
    QFileInfoList rawFileInfoList ;
    rawFileInfoList << tempRawFileDir.entryInfoList(filters, QDir::Files|QDir::NoDotAndDotDot);
    QString oldName;
    QString newName;
    QString rawFilePath;
    QString outputFilePath;
    QString type ;
    if(m_defaultPathData->get("type").toInt() == 1){
        type = "mp3";
    }else if(m_defaultPathData->get("type").toInt() == 2){
        type = "m4a";
    }else{
        type = "wav";
    }
    if(!rawFileInfoList.isEmpty()){

        rawFilePath = rawFileInfoList.at(0).absoluteFilePath();
        oldName = rawFileInfoList.at(0).absoluteFilePath().split("/").last();
        int pos = oldName.indexOf(".");
        newName = oldName.replace(pos+1,3,type);
        qDebug()<<"tempRawFilePath"<<rawFileInfoList.at(0).absoluteFilePath()
                <<"newName"<<newName;
        outputFilePath = m_defaultPathData->get("path").toString() + tr("Recorder") + "/"
                + newName;
        int num = MainWindow::mutual->m_subThread->
                  toConvertWAV( rawFilePath, outputFilePath.toLocal8Bit().data() );
        if(num >= 0){
            qDebug()<<"异常退出找到raw,且转码成功!";
        }

    }

    QFileInfoList fileList = Tools::getRecordingFileinfos();
    qDebug()<<"fileList"<<fileList;
    int fileCount = Tools::getRecordingFileinfos().count();
    m_preCount = Tools::getRecordingFileinfos().count();
    qDebug()<<"文件夹里文件有共计:"<<m_preCount<<"个";
    isFileNull(m_preCount);
    for(int i = 0;i <m_preCount;i++)
    {
        QString filepath = fileList.at(i).absoluteFilePath();
        QString name = filepath.split("/").last();
        QString timeStr = name.mid(0,14);
        QDateTime date = QDateTime::fromString( timeStr,"yyyyMMddhhmmss");
        QString str = date.toString("yyyy-MM-dd hh:mm:ss");
//        qDebug()<<"时间:"<<str;
        slotListItemAdd(filepath,str);//每当配置文件中有路径时就在list中更新一下
    }

}

void MainWindow::slotListItemAdd(QString fileAbsolutePath,QString recordTime)
{
    QFileInfo fileinfo(fileAbsolutePath);
    m_fileItem = new FileItem(fileAbsolutePath);
    if(fileinfo.suffix() == "mp3"&&!fileAbsolutePath.contains("Clip")){
        m_fileItem->setName_Time_Length(tr("Recording")+fileAbsolutePath.split("/").last(),
                                      recordTime,
                                      playerTotalTime(fileAbsolutePath));
    }else if(fileinfo.suffix() == "mp3"&&fileAbsolutePath.contains("Clip")){
        m_fileItem->setName_Time_Length(fileAbsolutePath.split("/").last(),
                                      recordTime,
                                      playerTotalTime(fileAbsolutePath));
    }
    QListWidgetItem *aItem = new QListWidgetItem(m_list);//添加自定义的item
    m_list->addItem(aItem);
    m_list->setItemWidget(aItem,m_fileItem);
    aItem->setSizeHint(QSize(0,64));
    isFileNull(m_list->count());//item个数从0开始增加时文件列表不应该显示"文件列表空"的字样

}

bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{

    if(obj == m_list)
    {
        if(event->type()==QEvent::Wheel)
        {
            QWheelEvent *wheelEvent=static_cast<QWheelEvent *>(event);
            if(wheelEvent->delta()>0)
            {
                //实现1，这里你可以填写自己想要实现的效果
                qDebug()<<"上";
            }
            else
            {
                //实现2，这里你可以填写自己想要实现的效果
                qDebug()<<"下";
            }
        }
    }
    else if(obj == this)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == Qt::Key_F1)  //将event转换为QKeyEvent,然后判断是否键
        {
            qDebug()<<"按压了F1";
            if (!m_DaemonIpcDbus->daemonIsNotRunning()){
                //F1快捷键打开用户手册，如kylin-recorder
                //由于是小工具类，下面的showGuide参数要填写"kylin-recorder"
                m_DaemonIpcDbus->showGuide("kylin-recorder");
            }
            return true;
        }

    }
    return QObject::eventFilter(obj,event);
}

void MainWindow::wheelEvent(QWheelEvent *wheel)
{
//    if(wheel->delta()>0)
//    {
//        qDebug()<<"上";
//    }
//    else
//    {
//        qDebug()<<"下";
//    }
}

void MainWindow::processArgs(QStringList args)
{
    //kwin接口唤醒
    qDebug()<<"先窗口置顶";
    KWindowSystem::forceActiveWindow(this->winId());
    if(m_isRecording){
        qDebug()<<"设备正在录音不能播放!";
        return;
    }
    qDebug()<<"选择的音频路径为:"<<args;
    qDebug()<<"Items有:"<<this->findChildren<FileItem*>()
           <<"列表共有"<<this->findChildren<FileItem*>().count()<<"个";
    int listCount = this->findChildren<FileItem*>().count();
    int fileCount = Tools::getRecordingFileinfos().count();//获取不同目录下的所有文件个数
    qDebug()<<"文件中有:"<<fileCount<<"个";
    QFileInfoList fileList = Tools::getRecordingFileinfos();
    if(!args.isEmpty())
    {
        QString selectStr = args.at(0);//选择串
        qDebug()<<"selectStr:"<<selectStr;
        QString tempStr ;//临时比对串
        int i = 0;
        for(i = 0;i < listCount;i++)
        {
            tempStr = fileList.at(i).absoluteFilePath();
            if(selectStr.contains(tempStr))
            {
                qDebug()<<"1111选择的Item是:"<<tempStr<<"  "<<i;
                PlayControl::getInstance().play_Audio(selectStr);
                this->findChildren<FileItem*>().at(i)->handlePlay();
                break;
            }
        }
        if(i>=this->findChildren<FileItem*>().count())
        {
            qDebug()<<"非录音列表文件，无法打开";
            QMessageBox::warning(this,tr("Warning"),
                                 tr("The file is not in the recording list,cannot be opened"));
            return;
        }
    }
}

//软件应用使用麦克风时提示正在使用的弹窗
void MainWindow::showNotify(QString message)
{
    QAudioDeviceInfo inputDevice(QAudioDeviceInfo::defaultInputDevice());
    if(inputDevice.deviceName().contains("multichannel-input")){
        qDebug()<<"多聲道輸入設備";
        m_devMessage = tr("Using multichannel device");
    }else{
        m_devMessage = tr("Microphone in use");
    }
    std::string str = m_devMessage.toStdString();
    const char* ch = str.c_str();
    qDebug()<<"彈窗";
    QDBusInterface iface("org.freedesktop.Notifications",
                         "/org/freedesktop/Notifications",
                         "org.freedesktop.Notifications",
                         QDBusConnection::sessionBus());
    QList<QVariant> args;
    args<<(tr("kylin-recorder"))
        <<((unsigned int) 0)
        <<QString("/usr/share/icons/ukui-icon-theme-default/48x48/apps/kylin-recorder.png")
        <<tr(ch) //显示的是什么类型的信息
        <<message //显示的具体信息
        <<QStringList()
        <<QVariantMap()
        <<(int)-1;
    iface.callWithArgumentList(QDBus::AutoDetect,"Notify",args);
}

void MainWindow::transChange()
{
    m_tran = m_pGsettingControlTrans->get("transparency").toDouble()*255;
    this->update();
}

//透明度按UI规范修改
void MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    p.setPen(Qt::NoPen);
    QColor color = palette().color(QPalette::Base);
    // QColor color = palette().color(QPalette::Window);
    color.setAlpha(m_tran);
    QPalette pal(this->palette());
    pal.setColor(QPalette::Window,QColor(color));
    this->setPalette(pal);
    QBrush brush =QBrush(color);
    p.setBrush(brush);
    p.drawRoundedRect(opt.rect,0,0);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
    return QWidget::paintEvent(event);
}

