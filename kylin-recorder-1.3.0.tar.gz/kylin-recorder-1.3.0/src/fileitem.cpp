#include "fileitem.h"

#include "mythread.h"
#include "mainwindow.h"
#include "tools.h"
#include "clipwidget.h"
#include "audiofileprocess.h"

FileItem::FileItem(QString fileAbsolutePath,QWidget *parent) : QWidget(parent)
{
    m_filePath = fileAbsolutePath;//每个Item的文件绝对路径
    initItemWid();//初始化ItemWid
    setItemWid();//设置ItemWid的界面
    initThemeGsetting();
}

void FileItem::initItemWid()
{
    m_pal = palette();                        //声明调色板
    m_splitLine = new QFrame(this);                //分割线
    m_playSlider = new CustomSlider(this);    //播放划块条
    m_recordFileNameLabel = new MyLabel(this);      //录音文件名
    m_startRecordTimeLabel = new QLabel(this);         //录音时间标签
    m_timelengthLabel = new QLabel(this);        //时间长度标签
    m_seatLabel = new QLabel(this);              //占位标签

    m_pal.setColor(QPalette::Text,QColor(140,140,140));
    m_startRecordTimeLabel->setPalette(m_pal);
    m_timelengthLabel->setPalette(m_pal);

    m_customPlayButton = new CustomButton(":/svg/svg/play-defalut-light.svg",
                                  ":/svg/svg/play-hover.svg",
                                  ":/svg/svg/play-click.svg",this);
    m_customPauseButton = new CustomButton(":/svg/svg/suspend-defalut-light.svg",
                                   ":/svg/svg/zanting_select_hover.svg",
                                   ":/svg/svg/suspend-click.svg");
    m_customDeleteButton = new CustomButton(":/svg/svg/delete-defalut-light.svg",
                                    ":/svg/svg/delete_hover.svg",
                                    ":/svg/svg/delete_click.svg",this);
    m_customClipButton = new CustomButton(":/svg/svg/edit-defalut-light.svg",
                                  ":/svg/svg/edit-hover.svg",
                                  ":/svg/svg/edit-click.svg",this);

    m_splitLinestackWidget = new QStackedWidget(this);   //分割线堆叠wid
    m_buttonStackWidget = new QStackedWidget(this);         //按钮的堆叠布局
    m_itemStackWidget = new QStackedWidget(this);        //整个item界面的堆叠布局(包括播放、剪裁两个界面)
    m_buttonStackWidget->installEventFilter(this);          //给stackWid安装事件过滤器
    m_firstWidget = new QWidget(this);                   //时间长短第一层Wid
    m_threeButtonWidget = new QWidget(this);//三个按钮的Wid

    m_itemBottomWidget = new QWidget(this);//列表项的底部Wid，有label和button两组控件
    m_itemWidget = new QWidget(this);
    m_fileNameDateTimeWidget = new QWidget(this);//文件名和日期时间的Wid

    m_itemBottomLayout = new QHBoxLayout(m_itemBottomWidget);//列表项的底部布局
    m_fileNameDateTimeLayout = new QVBoxLayout(m_fileNameDateTimeWidget);//文件名和录制时间布局
    m_timeLengthLayout = new QVBoxLayout(m_firstWidget);//时间的布局
    m_threeButtonLayout = new QHBoxLayout(m_threeButtonWidget);//三个按钮布局
    m_itemLayout = new QVBoxLayout(m_itemWidget);

    connect(m_customPlayButton,  &CustomButton::clicked,this,&FileItem::handlePlay);
    connect(m_customPauseButton, &CustomButton::clicked,this,&FileItem::handlePause);
    connect(m_customClipButton,  &CustomButton::clicked,this,&FileItem::toClipPage);
    connect(m_customDeleteButton,&CustomButton::clicked,this,&FileItem::delAudioFile);
    connect(m_playSlider,  &CustomSlider::sliderReleasedAt,this,&FileItem::setSliderPos);
    //确保一次触发多次使用,所有的item的文件都随字号变化,所以放在FileItem里
    connect(MainWindow::mutual,&MainWindow::itemFontStyleSignal,this,&FileItem::itemFontStyle);
    connect(this,&FileItem::addListItemSignal,MainWindow::mutual,&MainWindow::slotListItemAdd);

}

int FileItem::getInternalMoveTime()
{
    QFile file(m_filePath);
    int time = file.size()/96000;
    int x = 1;
    if(time >= 1){
        x = time*1000/m_playSlider->maximum();
    }else{
        x = (time+1)*1000/m_playSlider->maximum();
    }
    qDebug()<<"间隔"<<x<<"ms运动一次";
    return x;
}

void FileItem::handlePlay()
{
    //取此类的父类的所有FileItem类；findChildren：找所有的子类，findChild为找一个子类
    QList<FileItem*> items = this->parent()->findChildren<FileItem*>();
    qDebug()<<"item的个数："<<items.count();
    for(FileItem *item:items)
    {
        item->isOtherClipWidOpen();
    }
    if(Tools::fileExists(m_filePath)){
        m_threeButtonLayout->insertWidget(0,m_customPauseButton);
        m_threeButtonLayout->removeWidget(m_customPlayButton);
        m_customPlayButton->setParent(NULL);
        int internalTime = getInternalMoveTime();
        PlayControl::getInstance().moveTimer->start(internalTime);//每隔n秒进度加1
        PlayControl::getInstance().play_Audio(m_filePath);
        m_splitLinestackWidget->setCurrentIndex(1);

        connect(PlayControl::getInstance().moveTimer,&QTimer::timeout,this,&FileItem::handleMove);//用的时候连接
        connect(PlayControl::getInstance().getPlayer(),&QMediaPlayer::stateChanged,this,&FileItem::stateChanged);//用的时候连接
    }else{
        QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                             tr("The file path does not exist or has been deleted!"));
    }

}

void FileItem::handlePause()
{
    qDebug()<<"暂停的路径:"<<m_filePath;

    m_threeButtonLayout->insertWidget(0,m_customPlayButton);
    m_threeButtonLayout->removeWidget(m_customPauseButton);
    m_customPauseButton->setParent(NULL);

    PlayControl::getInstance().pause_Audio(m_filePath);
    m_splitLinestackWidget->setCurrentIndex(0);

    PlayControl::getInstance().moveTimer->stop();
    connect(PlayControl::getInstance().getPlayer(),&QMediaPlayer::stateChanged,this,&FileItem::stateChanged);//用的时候连接
}

void FileItem::setSliderPos(qint64 value)
{

    //计算公式：当前player进度 = player总进度 * playSlider的当前值 / playSlider总长度
    qint64 currentPlayerPos = PlayControl::getInstance().getPlayer()->duration()*value/m_playSlider->maximum();
    qDebug()<<"滑动条value:"<<value<<"当前player进度:"<<currentPlayerPos;

    PlayControl::getInstance().play_Audio(m_filePath);
    if(PlayControl::getInstance().getAudioState() == QMediaPlayer::PlayingState){
        qDebug()<<"播放的位置";
        m_movePos = value;//相对位置+按钮宽度=游标的位置
    }else{
        qDebug()<<"没播放过从0开始";
        m_movePos = 0;
    }
    PlayControl::getInstance().setPosition(currentPlayerPos);
    int internalTime = getInternalMoveTime();
    PlayControl::getInstance().moveTimer->start(internalTime);//每隔n秒进度加1

}

void FileItem::handleMove()
{
    if((m_movePos<m_playSlider->maximum()-1))
    {
        m_movePos++;
        m_playSlider->setValue(m_movePos);
//        qDebug()<<"movePos:"<<movePos;
    }
    else
    {
        qDebug()<<"停止了";
        PlayControl::getInstance().moveTimer->stop();
        m_movePos = 0;
    }
}

void FileItem::stateChanged(QMediaPlayer::State stateNow)
{
    if(PlayControl::getInstance().getAudioState() == QMediaPlayer::StoppedState)
    {
        qDebug()<<"列表播放结束 停止"<<m_filePath;
        m_movePos = 0;
        m_playSlider->setValue(m_movePos);
        m_splitLinestackWidget->setCurrentIndex(0);
        m_threeButtonLayout->insertWidget(0,m_customPlayButton);
        m_threeButtonLayout->removeWidget(m_customPauseButton);
        m_customPauseButton->setParent(NULL);

    }
    disconnect(PlayControl::getInstance().moveTimer,&QTimer::timeout,this,&FileItem::handleMove);//防止多次连接，每次状态改变后需要断开连接
    disconnect(PlayControl::getInstance().getPlayer(),&QMediaPlayer::stateChanged, this,&FileItem::stateChanged);//防止多次连接，每次状态改变后需要断开连接
}

void FileItem::itemFontStyle(QFont fontStyle)
{
    m_startRecordTimeLabel->setFont(fontStyle);
    m_recordFileNameLabel->setFont(fontStyle);
    m_timelengthLabel->setFont(fontStyle);
}

void FileItem::setItemWid()
{

    QString fontType = MainWindow::mutual->m_themeData->get("systemFont").toString();
    int fontSize = MainWindow::mutual->m_themeData->get("systemFontSize").toInt();
    QFont fontStyle(fontType,fontSize);
    m_recordFileNameLabel->setFont(fontStyle);
    m_startRecordTimeLabel->setFont(fontStyle);         //录音时间标签
    m_timelengthLabel->setFont(fontStyle);        //时间长度标签

    m_splitLine->setFixedHeight(1);
    m_splitLine->setStyleSheet("background-color:transparent;");//让线透明

    m_customPlayButton->setFixedSize(32,32);//设置按钮大小
    m_customPlayButton->setToolTip(tr("Play"));
    m_customPauseButton->setFixedSize(32,32);
    m_customPauseButton->setToolTip(tr("Pause"));
    m_customDeleteButton->setFixedSize(32,32);//设置按钮大小
    m_customDeleteButton->setToolTip(tr("Delete"));
    m_customClipButton->setFixedSize(32,32);
    m_customClipButton->setToolTip(tr("Clip"));

    m_fileNameDateTimeLayout->addWidget(m_recordFileNameLabel);
    m_fileNameDateTimeLayout->addWidget(m_startRecordTimeLabel);
    m_fileNameDateTimeLayout->setSpacing(0);//调整这俩Label的内距
    m_fileNameDateTimeLayout->setContentsMargins(0,0,0,0);//调整这俩Label的外距
    m_fileNameDateTimeWidget->setLayout(m_fileNameDateTimeLayout);
    m_fileNameDateTimeWidget->setFixedWidth(270);

    m_timeLengthLayout->addWidget(m_seatLabel,0,Qt::AlignRight);
    m_timeLengthLayout->addWidget(m_timelengthLabel,0,Qt::AlignRight);
    m_timeLengthLayout->setContentsMargins(0,0,0,2);//
    m_firstWidget->setLayout(m_timeLengthLayout);
    m_firstWidget->setFixedWidth(160);

    m_splitLinestackWidget->addWidget(m_splitLine);
    m_splitLinestackWidget->addWidget(m_playSlider);
    m_splitLinestackWidget->setFixedHeight(10);

    m_threeButtonLayout->addWidget(m_customPlayButton);//2020.11.20 由于依赖问题此播放问题解决。
    m_threeButtonLayout->removeWidget(m_customPauseButton);
    m_threeButtonLayout->addWidget(m_customClipButton);
    m_threeButtonLayout->addWidget(m_customDeleteButton,0,Qt::AlignRight);
    m_threeButtonLayout->setContentsMargins(50,0,0,0);
    m_threeButtonWidget->setLayout(m_threeButtonLayout);

    m_buttonStackWidget->addWidget(m_firstWidget);
    m_buttonStackWidget->addWidget(m_threeButtonWidget);
    m_itemStackWidget->addWidget(m_itemWidget);

    m_itemBottomLayout->addWidget(m_fileNameDateTimeWidget);//录音名与开始录制时间的布局
    m_itemBottomLayout->addWidget(m_buttonStackWidget,0,Qt::AlignRight);//按钮和时间长度的堆叠布局
    m_itemBottomLayout->setSpacing(0);
    m_itemBottomLayout->setContentsMargins(30,0,20,0);
    m_itemBottomWidget->setLayout(m_itemBottomLayout);
    m_itemBottomWidget->setFixedHeight(57);

    m_itemLayout->addWidget(m_splitLinestackWidget,0,Qt::AlignVCenter);
    m_itemLayout->addWidget(m_itemBottomWidget);
    m_itemLayout->setContentsMargins(0,0,0,0);
    m_itemLayout->setSpacing(0);
    m_itemWidget->setLayout(m_itemLayout);



}

void FileItem::initThemeGsetting()
{
    connect(MainWindow::mutual->m_themeData, &QGSettings::changed, this, [=]  (const QString &key)
    {
        if(key == "styleName"){
            m_itemThemeColor = MainWindow::mutual->m_themeData->get("styleName").toString();
            themeStyle(m_itemThemeColor);
        }

    });
    themeStyle(MainWindow::mutual->m_themeData->get("styleName").toString());
}

void FileItem::themeStyle(QString themeColor)
{
    if(themeColor == "ukui-dark"||themeColor == "ukui-black"){

        m_customPlayButton->setImagePath(":/svg/svg/play-defalut-dark.svg",
                                 ":/svg/svg/play-hover.svg",
                                 ":/svg/svg/play-click.svg");
        m_customPauseButton->setImagePath(":/svg/svg/suspend-defalut-dark.svg",
                                 ":/svg/svg/zanting_select_hover.svg",
                                 ":/svg/svg/suspend-click.svg");
        m_customDeleteButton->setImagePath(":/svg/svg/delet-defalut-dark.svg",
                                   ":/svg/svg/delete_hover.svg",
                                   ":/svg/svg/delete_click.svg");
    }else{

        m_customPlayButton->setImagePath(":/svg/svg/play-defalut-light.svg",
                                 ":/svg/svg/play-hover.svg",
                                 ":/svg/svg/play-click.svg");
        m_customPauseButton->setImagePath(":/svg/svg/suspend-defalut-light.svg",
                                 ":/svg/svg/zanting_select_hover.svg",
                                 ":/svg/svg/suspend-click.svg");
        m_customDeleteButton->setImagePath(":/svg/svg/delete-defalut-light.svg",
                                   ":/svg/svg/delete_hover.svg",
                                   ":/svg/svg/delete_click.svg");
    }
}

void FileItem::setName_Time_Length(QString nameStr,QString timeStr,QString lengthStr)
{
    m_recordFileNameLabel->setText(nameStr);
    m_startRecordTimeLabel->setText(timeStr);
    m_timelengthLabel->setText(lengthStr);
}

void FileItem::toClipPage()
{
    QList<FileItem*> items = this->parent()->findChildren<FileItem*>();//取此类的父类的所有FileItem类；findChildren：找所有的子类，findChild为找一个子类
    qDebug()<<"item的个数："<<items.count();
    for(FileItem *item:items)
    {
        item->isOtherClipWidOpen();
    }

    AudioFileProcess *audioFile = new AudioFileProcess(this);
    int value_Type = audioFile->wavFile_Analy(m_filePath);
    if(value_Type == 1){

        ClipWidget *clipWid = new ClipWidget(m_filePath,this);
        clipWid->setObjectName("clipWid");
        m_itemStackWidget->addWidget(clipWid);
        connect(clipWid,&ClipWidget::cancel_ClipSignal,this,&FileItem::cancel);
        connect(clipWid,&ClipWidget::finish_ClipSignal,this,&FileItem::finish);
        connect(clipWid,&ClipWidget::coverUpdateListSignal,this,&FileItem::updateListDisplay);
        clipWid->display_Wave();

    }else if(value_Type == 0){
        QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                             tr("Time is too short"));
        return ;
    }else if(value_Type == -2){
        QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                             tr("The file path does not exist or has been deleted!"));
        return ;
    }else if(value_Type == -1){

        //不能解析非录音生成的录音文件
        QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                             tr("Unable to parse the waveform of audio file generated by non recorder！"));
        return ;

    }
    m_itemStackWidget->setCurrentIndex(1);


}

void FileItem::updateListDisplay(QString filePath)
{
    int x = this->parent()->findChildren<FileItem*>().indexOf(this);
    MainWindow::mutual->m_list->takeItem(MainWindow::mutual->m_list->count()-1-x);//删除操作
    qDebug()<<"文件名:"<<filePath<<"所在列表的索引:"<<x;
    emit addListItemSignal(filePath,"");

}

void FileItem::cancel()
{
    qDebug()<<"剪裁取消";//
    PlayControl::getInstance().setPosition(0);
    PlayControl::getInstance().clipMoveTimer->stop();//游标随时间移动也要停止
    PlayControl::getInstance().getPlayer()->stop();
    if(m_itemStackWidget->currentWidget() != nullptr&&m_itemStackWidget->currentIndex() == 1){

        qDebug()<<"有其他剪裁界面的释放掉"<<m_itemStackWidget->currentWidget()->objectName();
        m_itemStackWidget->currentWidget()->deleteLater();

    }
    m_itemStackWidget->setCurrentIndex(0);
}

void FileItem::finish()
{
    qDebug()<<"剪裁完成";
    //要考虑是否替换文件(下次可继续裁剪)或者将剪裁后的文件放在其他位置(要再考虑下次是否还能剪裁了)
    PlayControl::getInstance().setPosition(0);
    PlayControl::getInstance().clipMoveTimer->stop();//游标随时间移动也要停止
    PlayControl::getInstance().getPlayer()->stop();
    if(m_itemStackWidget->currentWidget() != nullptr&&m_itemStackWidget->currentIndex() == 1){

        qDebug()<<"有其他剪裁界面的释放掉"<<m_itemStackWidget->currentWidget()->objectName();
        m_itemStackWidget->currentWidget()->deleteLater();

    }
    m_itemStackWidget->setCurrentIndex(0);
}

void FileItem::isOtherClipWidOpen()
{
    if(m_itemStackWidget ->currentIndex() != 0)//若有其他的剪裁界面则先将其他的收回去
    {
        qDebug()<<"有其他剪裁界面可切换";
        if(PlayControl::getInstance().getAudioState() == QMediaPlayer::PlayingState)
        {
            PlayControl::getInstance().clipMoveTimer->stop();//游标随时间移动也要停止
            PlayControl::getInstance().getPlayer()->stop();

        }
        if(m_itemStackWidget->currentWidget() != nullptr&&m_itemStackWidget->currentIndex() == 1){

            qDebug()<<"有其他剪裁界面的释放掉"<<m_itemStackWidget->currentWidget()->objectName();
            m_itemStackWidget->currentWidget()->deleteLater();

        }
        m_itemStackWidget -> setCurrentIndex(0);

    }
}

void FileItem::delAudioFile()
{
    int fileCount = Tools::getRecordingFileinfos().count();//获取不同目录下的所有文件个数
    QString delFilePath = m_filePath;//filePath作为FileItem的一个属性
    qDebug()<<"删除的是："<<delFilePath;//前提是鼠标悬浮有焦点之后才可以锁定此FileItem的属性
    if(Tools::fileExists(delFilePath))
    {
        if(PlayControl::getInstance().getPlayer()->state()==QMediaPlayer::PlayingState)
        {
            QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                                 tr("Playing, please stop and delete!"));
            return ;
        }
//        qDebug()<<"输出删除之前的Item地址"<<this->parent()->findChildren<FileItem*>();
        int x = this->parent()->findChildren<FileItem*>().indexOf(this);
        MainWindow::mutual->m_list->takeItem(MainWindow::mutual->m_list->count()-1-x);//删除操作
        qDebug()<<"路径存在，删除"<<delFilePath;
        MainWindow::mutual->isFileNull(MainWindow::mutual->m_list->count());//传item个数
        deleteFile(delFilePath);//移入回收站
        return ;

    }
    else
    {

        int y = this->parent()->findChildren<FileItem*>().indexOf(this);
        qDebug()<<"第"<<y<<"个不存在,直接删除:";
        MainWindow::mutual->m_list->takeItem(MainWindow::mutual->m_list->count()-1-y);//删除list列表的item操作
        MainWindow::mutual->isFileNull(MainWindow::mutual->m_list->count());//传item个数
        return ;
    }
}

void FileItem::rightClickedMenuRequest()//右击弹出Menu菜单
{
    qDebug()<<"按压了右键!弹出Menu菜单";
    m_menu = new QMenu();
    m_actionSave = new QAction();
    m_actionOpenFolder = new QAction();

    connect(m_actionSave,&QAction::triggered,this,&FileItem::actionSaveasSlot);
    connect(m_actionOpenFolder,&QAction::triggered,this,&FileItem::actionOpenFolderSlot);
    m_actionSave->setText(tr("Save as"));
    m_actionOpenFolder->setText(tr("Open folder position"));

    m_menu->addAction(m_actionSave);
    m_menu->addAction(m_actionOpenFolder);//2020/12/12禁用
    m_menu->exec(QCursor::pos());

    m_menu->deleteLater();
    m_actionSave->deleteLater();
    m_actionOpenFolder->deleteLater();
}

//右键另存为其他路径
void FileItem::actionSaveasSlot()
{
    QString oldFilePath = this->m_filePath;
    QString newFilePath = "";
    if(Tools::fileExists(oldFilePath)){
        //选择文件目录
        QString selectDirPath = "";
        selectDirPath = QFileDialog::getExistingDirectory(
                                MainWindow::mutual,
                                tr("Select a file storage directory"),
                                "/");

        int value = Tools::inputEditJudge(selectDirPath + "/");
        qDebug()<<"另存为的目录:"<<selectDirPath<<"value:"<<value;
        if(value == 1){
            newFilePath = selectDirPath + "/" + QFileInfo(oldFilePath).fileName();
            qDebug()<<"将老文件路径"<<oldFilePath<<"拷贝到新文件路径:"<<newFilePath;
            QFile::copy(oldFilePath,newFilePath);
        }else{
            return ;
        }
    }else{
        QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                             tr("The file path does not exist or has been deleted!"));
    }
}

//右键打开文件位置并选中
void FileItem::actionOpenFolderSlot()
{
    QString openedPath = m_filePath;
    if(Tools::fileExists(openedPath)){
        QDBusInterface sessionDbus("org.freedesktop.FileManager1",
                                   "/org/freedesktop/FileManager1",
                                   "org.freedesktop.FileManager1",
                                   QDBusConnection::sessionBus(),this);
        QStringList items;
        items.push_back(openedPath);
        QString startUpId = "";
        sessionDbus.call("ShowItems",items,startUpId);
    }else{
        QMessageBox::warning(MainWindow::mutual,tr("Warning"),
                            tr("The file path does not exist or has been deleted!"));
    }

//    QProcess process;
//    QString str = "\"" + openedPath +"\"";
//    process.startDetached("peony --show-items " + str);
}

void FileItem::mousePressEvent(QMouseEvent *mouseEvent)
{
    if(mouseEvent->button() == Qt::RightButton){
        if (mouseEvent->type() == QEvent::MouseButtonPress)
        {
            qDebug()<<"右键点击";
            rightClickedMenuRequest();//右击弹窗:1另存为、2打开文件
        }
    }
}

bool FileItem::eventFilter(QObject *obj, QEvent *event)   //鼠标滑块点击
{
    if(obj == m_buttonStackWidget)//悬浮特效、点击特效、右击特效
    {
        m_buttonStackWidget->setAttribute(Qt::WA_Hover,true);//****关键代码,若不加此行代码则没有悬浮特效****

        if(event->type() == QEvent::HoverEnter||event->type() == QEvent::HoverMove)//显示浮窗
        {
            if(MainWindow::mutual->m_isRecording){
                m_buttonStackWidget->setCurrentIndex(0);//切换至录音按钮stackLayout
            }else{
                m_buttonStackWidget->setCurrentIndex(1);//切换至录音按钮stackLayout
            }
        }

    }
    return QWidget::eventFilter(obj,event);
}

void FileItem::deleteFile(QString savepath)
{
    _processStart("gio",QStringList() << "trash" << savepath);
}

void FileItem::_processStart(QString cmd, QStringList arguments)
{
    if(!m_processDEL){
        m_processDEL = new QProcess(this);
    }
    m_processDEL->start(cmd,arguments);
    m_processDEL->waitForStarted();
    m_processDEL->waitForFinished();
}

void FileItem::processLog()
{
    qDebug()<<"*******process error*******\n"
           << QString::fromLocal8Bit(m_processDEL->readAllStandardError())
           <<"\n*******process error*******";
}

void FileItem::enterEvent(QEvent *event)
{
//    qDebug()<<"当前文件名:"<<filePath;
    int R = 55,G = 144,B = 250;
    m_pal.setColor(QPalette::Text,QColor(R,G,B));
    m_recordFileNameLabel->setPalette(m_pal);
    m_startRecordTimeLabel->setPalette(m_pal);
    m_timelengthLabel->setPalette(m_pal);
    //显示浮窗
    if(MainWindow::mutual->m_isRecording){
        m_buttonStackWidget->setCurrentIndex(0);//切换至录音按钮stackLayout
    }else{
        m_buttonStackWidget->setCurrentIndex(1);//切换至录音按钮stackLayout
    }


}

void FileItem::leaveEvent(QEvent *event)
{
//    qDebug()<<"离开";
    int R = 255,G = 255,B = 255;
    m_itemThemeColor = MainWindow::mutual->m_themeData->get("styleName").toString();
    if(m_itemThemeColor == "ukui-dark"||m_itemThemeColor == "ukui-black"){
        R = 255,G = 255,B = 255;
    }else{
        R = 0,G = 0,B = 0;
    }
    m_pal.setColor(QPalette::Text,QColor(R,G,B));
    m_recordFileNameLabel->setPalette(m_pal);
    m_pal.setColor(QPalette::Text,QColor(140,140,140));
    m_timelengthLabel->setPalette(m_pal);
    m_startRecordTimeLabel->setPalette(m_pal);
    m_buttonStackWidget->setCurrentIndex(0);//切换至显示时长的布局
}

FileItem::~FileItem()
{
//    qDebug()<<"释放FileItem";
    m_customPauseButton->deleteLater();
    this->deleteLater();
}
