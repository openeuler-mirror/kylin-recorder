<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>ClipWidget</name>
    <message>
        <location filename="../src/clipwidget.cpp" line="139"/>
        <source>Audition</source>
        <translation>试听</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="141"/>
        <source>Pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="144"/>
        <location filename="../src/clipwidget.cpp" line="413"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="147"/>
        <source>Finish</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="340"/>
        <source>Save New</source>
        <translation>存为新文件</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="341"/>
        <source>Cover Current</source>
        <translation>覆盖当前文件</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="358"/>
        <source>Select a file storage directory</source>
        <translation>选择一个文件存储目录</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="390"/>
        <location filename="../src/clipwidget.cpp" line="438"/>
        <source>The duration of the clip cannot be less than 1s, and you must drag at least one slider to start this activity!</source>
        <translation>剪辑时间不得少于1s,且您必须拖拽至少一个滑块作为此活动开始!</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="452"/>
        <source>New File:</source>
        <translation>新文件:</translation>
    </message>
    <message>
        <source>The duration of the clip cannot be less than 1s, and the initial start and end positions cannot be used as the start and end positions of the clip!</source>
        <translation type="vanished">剪辑时长不得少于1s,且初始的开始和结束位置不能作为剪辑的开始和结束位置!</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="409"/>
        <source>Hint</source>
        <translation>提示</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="vanished">消息</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="410"/>
        <source>This will overwrite the original file path,are you sure?</source>
        <translation>此举将覆盖当前文件,您确定吗?</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="412"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="389"/>
        <location filename="../src/clipwidget.cpp" line="437"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>The duration of the clip cannot be less than 1s, and the duration of the clip cannot be the duration of the original file!</source>
        <translation type="vanished">剪辑时长不能小于1s,剪辑时长不能与原时长相同!</translation>
    </message>
    <message>
        <source>This storage path is illegal!</source>
        <translation type="vanished">存储路径非法!</translation>
    </message>
    <message>
        <source>The file name cannot exceed 20 characters!</source>
        <translation type="vanished">文件名不得超过20个字符!</translation>
    </message>
    <message>
        <location filename="../src/clipwidget.cpp" line="451"/>
        <source>Clip Finished!</source>
        <translation>剪辑完成!</translation>
    </message>
</context>
<context>
    <name>FileItem</name>
    <message>
        <location filename="../src/fileitem.cpp" line="203"/>
        <source>Play</source>
        <translation>播放</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="205"/>
        <source>Pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="207"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="107"/>
        <location filename="../src/fileitem.cpp" line="325"/>
        <location filename="../src/fileitem.cpp" line="329"/>
        <location filename="../src/fileitem.cpp" line="335"/>
        <location filename="../src/fileitem.cpp" line="416"/>
        <location filename="../src/fileitem.cpp" line="484"/>
        <location filename="../src/fileitem.cpp" line="503"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="209"/>
        <source>Clip</source>
        <translation>剪辑</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="326"/>
        <source>Time is too short</source>
        <translation>时间过短</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="336"/>
        <source>Unable to parse the waveform of audio file generated by non recorder！</source>
        <translation>不能解析非录音文件生成的音频文件!</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="417"/>
        <source>Playing, please stop and delete!</source>
        <translation>播放中,请停止后删除!</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="449"/>
        <source>Save as</source>
        <translation>另存为</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="450"/>
        <source>Open folder position</source>
        <translation>打开文件位置</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="471"/>
        <source>Select a file storage directory</source>
        <translation>选择一个文件存储目录</translation>
    </message>
    <message>
        <location filename="../src/fileitem.cpp" line="108"/>
        <location filename="../src/fileitem.cpp" line="330"/>
        <location filename="../src/fileitem.cpp" line="485"/>
        <location filename="../src/fileitem.cpp" line="504"/>
        <source>The file path does not exist or has been deleted!</source>
        <translation>文件路径不存在或已被删除!</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="206"/>
        <location filename="../src/mainwindow.cpp" line="250"/>
        <location filename="../src/mainwindow.cpp" line="1328"/>
        <source>Recorder</source>
        <translation>录音</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <source>Set</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="256"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="260"/>
        <source>Menu</source>
        <translation>菜单</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="271"/>
        <source>Mini</source>
        <translation>迷你</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="280"/>
        <source>Minimize</source>
        <translation>最小化</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="298"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="307"/>
        <location filename="../src/mainwindow.cpp" line="313"/>
        <location filename="../src/mainwindow.cpp" line="1362"/>
        <source>Recording</source>
        <translation>录音</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="397"/>
        <source>Finish</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="423"/>
        <source>File List</source>
        <translation>文件列表</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="703"/>
        <source>None of the Recording File</source>
        <translation>列表无录音文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="955"/>
        <location filename="../src/mainwindow.cpp" line="1082"/>
        <location filename="../src/mainwindow.cpp" line="1263"/>
        <location filename="../src/mainwindow.cpp" line="1464"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="955"/>
        <source>No input device detected!</source>
        <translation>没检测到输入设备!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1083"/>
        <location filename="../src/mainwindow.cpp" line="1264"/>
        <source>Audio is playing, please stop and record again!</source>
        <translation>有音频在播放，请停止并重新录制!</translation>
    </message>
    <message>
        <source>There is audio playing, please stop after recording!</source>
        <translation type="vanished">音频正在播放,请停止后录音!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1049"/>
        <source>start</source>
        <translation>继续</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1249"/>
        <source>Tips From Recorder</source>
        <translation>来自录音的提示</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1465"/>
        <source>The file is not in the recording list,cannot be opened</source>
        <translation>非录音列表文件，无法打开</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1477"/>
        <source>Using multichannel device</source>
        <translation>使用多声道输入设备</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1479"/>
        <source>Microphone in use</source>
        <translation>麦克风在使用</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1489"/>
        <source>kylin-recorder</source>
        <translation>录音</translation>
    </message>
</context>
<context>
    <name>MiniWindow</name>
    <message>
        <location filename="../src/miniwindow.cpp" line="97"/>
        <source>Recorder</source>
        <translation>录音</translation>
    </message>
    <message>
        <location filename="../src/miniwindow.cpp" line="102"/>
        <source>Recording</source>
        <translation>录音</translation>
    </message>
    <message>
        <location filename="../src/miniwindow.cpp" line="108"/>
        <source>Finish</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../src/miniwindow.cpp" line="117"/>
        <location filename="../src/miniwindow.cpp" line="249"/>
        <source>Pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../src/miniwindow.cpp" line="129"/>
        <source>Restore</source>
        <translation>复原</translation>
    </message>
    <message>
        <location filename="../src/miniwindow.cpp" line="137"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../src/miniwindow.cpp" line="219"/>
        <location filename="../src/miniwindow.cpp" line="319"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/miniwindow.cpp" line="220"/>
        <location filename="../src/miniwindow.cpp" line="320"/>
        <source>Audio is playing, please stop and record again!</source>
        <translation>有音频在播放，请停止并重新录制!</translation>
    </message>
    <message>
        <source>There is audio playing, please stop after recording!</source>
        <translation type="vanished">音频在播放,请停止后再录音!</translation>
    </message>
    <message>
        <location filename="../src/miniwindow.cpp" line="254"/>
        <source>Start</source>
        <translation>继续</translation>
    </message>
</context>
<context>
    <name>MyThread</name>
    <message>
        <location filename="../src/mythread.cpp" line="180"/>
        <location filename="../src/mythread.cpp" line="185"/>
        <location filename="../src/mythread.cpp" line="190"/>
        <location filename="../src/mythread.cpp" line="200"/>
        <location filename="../src/mythread.cpp" line="205"/>
        <location filename="../src/mythread.cpp" line="210"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mythread.cpp" line="180"/>
        <location filename="../src/mythread.cpp" line="200"/>
        <source>.mp3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mythread.cpp" line="185"/>
        <location filename="../src/mythread.cpp" line="205"/>
        <source>.wav</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mythread.cpp" line="190"/>
        <location filename="../src/mythread.cpp" line="210"/>
        <source>.m4a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mythread.cpp" line="361"/>
        <location filename="../src/mythread.cpp" line="366"/>
        <location filename="../src/mythread.cpp" line="368"/>
        <source>Recorder</source>
        <translation>录音</translation>
    </message>
    <message>
        <location filename="../src/mythread.cpp" line="631"/>
        <source>Select a file storage directory</source>
        <translation>选择一个存储目录</translation>
    </message>
    <message>
        <location filename="../src/mythread.cpp" line="639"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/mythread.cpp" line="639"/>
        <source>Do not enter illegal file name</source>
        <translation>不要输入非法文件名</translation>
    </message>
</context>
<context>
    <name>Save</name>
    <message>
        <location filename="../src/save.cpp" line="135"/>
        <location filename="../src/save.cpp" line="146"/>
        <location filename="../src/save.cpp" line="164"/>
        <source>Select a file storage directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../src/settings.cpp" line="49"/>
        <location filename="../src/settings.cpp" line="62"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="77"/>
        <source>Alter</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="99"/>
        <source>Storage:</source>
        <translation>文件存储:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="108"/>
        <location filename="../src/settings.cpp" line="112"/>
        <location filename="../src/settings.cpp" line="240"/>
        <location filename="../src/settings.cpp" line="257"/>
        <location filename="../src/settings.cpp" line="261"/>
        <source>Recorder</source>
        <translation>录音</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="125"/>
        <source>Format:</source>
        <translation>文件格式:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="130"/>
        <source>mp3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="138"/>
        <source>Source:</source>
        <translation>录音来源:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="144"/>
        <source>Microphone</source>
        <translation>麦克风</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="145"/>
        <source>System Inside</source>
        <translation>系统内部</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="234"/>
        <source>Select a file storage directory</source>
        <translation>选择文件存储目录</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="284"/>
        <location filename="../src/settings.cpp" line="299"/>
        <location filename="../src/settings.cpp" line="307"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="284"/>
        <location filename="../src/settings.cpp" line="307"/>
        <source>This storage path is illegal!</source>
        <translation>存储路径非法!</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="299"/>
        <source>The file name cannot exceed 20 characters!</source>
        <translation>文件名不得超过20个字符!</translation>
    </message>
</context>
<context>
    <name>TipWindow</name>
    <message>
        <source>Transcoding...</source>
        <translation type="vanished">解析中...</translation>
    </message>
    <message>
        <location filename="../src/tipwindow.cpp" line="20"/>
        <source>Analysis...</source>
        <translation>解析...</translation>
    </message>
</context>
<context>
    <name>Tools</name>
    <message>
        <location filename="../src/tools.cpp" line="26"/>
        <location filename="../src/tools.cpp" line="40"/>
        <location filename="../src/tools.cpp" line="48"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/tools.cpp" line="26"/>
        <location filename="../src/tools.cpp" line="48"/>
        <source>This storage path is illegal!</source>
        <translation>存储路径非法!</translation>
    </message>
    <message>
        <location filename="../src/tools.cpp" line="40"/>
        <source>The file name cannot exceed 20 characters!</source>
        <translation>文件名不得超过20个字符!</translation>
    </message>
    <message>
        <location filename="../src/tools.cpp" line="71"/>
        <source>Recorder</source>
        <translation>录音</translation>
    </message>
</context>
<context>
    <name>menuModule</name>
    <message>
        <source>Setting</source>
        <translation type="vanished">设置</translation>
    </message>
    <message>
        <location filename="../src/menumodule.cpp" line="29"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="../src/menumodule.cpp" line="26"/>
        <location filename="../src/menumodule.cpp" line="125"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/menumodule.cpp" line="32"/>
        <location filename="../src/menumodule.cpp" line="123"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../src/menumodule.cpp" line="35"/>
        <location filename="../src/menumodule.cpp" line="121"/>
        <location filename="../src/menumodule.cpp" line="192"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../src/menumodule.cpp" line="38"/>
        <location filename="../src/menumodule.cpp" line="119"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../src/menumodule.cpp" line="250"/>
        <source>Version: </source>
        <translation>版本:</translation>
    </message>
    <message>
        <location filename="../src/menumodule.cpp" line="253"/>
        <location filename="../src/menumodule.cpp" line="314"/>
        <location filename="../src/menumodule.cpp" line="330"/>
        <source>Service &amp; Support: </source>
        <translation>服务与支持:</translation>
    </message>
    <message>
        <location filename="../src/menumodule.cpp" line="268"/>
        <source>The UI is friendly and easy to operate. It supports by microphone ,playing and deleting in file list, and switching between Mini mode and Theme mode</source>
        <translation>界面友好操作简单,支持麦克风录制,支持在文件列表播放和删除,支持迷你和主题模式切换</translation>
    </message>
    <message>
        <source>The UI is friendly and easy to operate. It supports MP3 audio formats by microphone, playing and deleting in file list, and switching between Mini mode and Theme mode</source>
        <translation type="vanished">界面友好操作简单,支持麦克风录制MP3音频格式,支持文件列表中播放和删除,支持迷你和主题模式切换</translation>
    </message>
    <message>
        <source>The UI is friendly and easy to operate. It supports MP3 and WAV audio formats by microphone, playing and deleting in file list, and switching between Mini mode and Theme mode</source>
        <translation type="vanished">界面友好操作简单,支持麦克风录制MP3和WAV音频格式,支持文件列表中播放和删除,支持迷你模式和主题模式切换</translation>
    </message>
    <message>
        <location filename="../src/menumodule.h" line="42"/>
        <source>Recorder</source>
        <translation>录音</translation>
    </message>
</context>
</TS>
