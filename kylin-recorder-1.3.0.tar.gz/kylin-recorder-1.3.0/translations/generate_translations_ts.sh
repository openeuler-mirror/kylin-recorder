#!/bin/bash

project_path=$(cd `dirname $0`; pwd)
cd $project_path/..

lupdate ./src -ts translations/kylin-recorder_zh_CN.ts
